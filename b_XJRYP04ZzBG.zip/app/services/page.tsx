"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Banknote,
  Building2,
  Heart,
  Scale,
  Cpu,
  RefreshCw,
  Leaf,
  ChevronRight,
  CreditCard,
  FileText,
  Stethoscope,
  Phone,
  Brain,
  Gavel,
  Calculator,
  Key,
  Tractor,
  Drone,
  BarChart3,
  Recycle,
  Handshake,
  Truck,
  Sun,
  Award,
  Wrench,
  Search,
  Star,
  Clock,
  CheckCircle2,
  Zap,
  Shield,
  Target
} from "lucide-react"

const serviceCategories = [
  {
    id: "finance",
    title: "Finance",
    subtitle: "Kredyty, leasing, ubezpieczenia - banks dla rolników",
    icon: Banknote,
    color: "bg-green-500",
    badge: "NEW",
    badgeColor: "bg-green-500",
    services: [
      { name: "Kredyt Rolniczy PKO BP", description: "Do 500 000 zł · RRSO 7,2% · Szybka decyzja online", badge: "Rekomendacja", hot: true },
      { name: "Leasing Maszyn BNP Paribas", description: "Bez wpłaty własnej · 60 mies. · John Deere, Claas", badge: "Niskie koszty", hot: false },
      { name: "Ubezpieczenia Agro IDB Bank", description: "Uprawy, maszyny, budynki · Najbardziej efektywna oferta", badge: null, hot: false },
      { name: "Doradca Dotacji EU 2023-2027", description: "KPO, Modernizacja ARiMR, PROW · Kompleksowa pomoc do końca", badge: null, hot: false },
    ]
  },
  {
    id: "eurzad",
    title: "eUrząd",
    subtitle: "Cyfrowa biurokracja w jednym miejscu",
    icon: Building2,
    color: "bg-blue-500",
    badge: null,
    services: [
      { name: "KSeF & Portal Rolnika", description: "30 e-usług · Faktury · Dokumentacja ARiMR", badge: "Nowość", hot: true },
      { name: "Energetyka OZE (PV+)", description: "Zarządzanie PV fotowoltaiką · Rakauna energii", badge: null, hot: false },
      { name: "Centrum Innowacji AGROSTRATEǴ", description: "Generator wniosków EU 2025 · Najnowsza pomoc", badge: null, hot: false },
    ]
  },
  {
    id: "health",
    title: "Zdrowie Rolnika",
    subtitle: "Telemedycyna i profilaktyka zawodowa",
    icon: Heart,
    color: "bg-red-500",
    badge: null,
    services: [
      { name: "Telemedycyna 24h", description: "Konsultacje lekarskie online · konsultacje, recepty", badge: null, hot: false },
      { name: "Profilaktyka KRUS", description: "Automatyczne powiadomienia o badaniach obowiązkowych", badge: null, hot: false },
      { name: "Wsparcie Psychologiczne", description: "Anonimowa konsultacja · stres, wypalenie, samotność", badge: "nowe", hot: true },
    ]
  },
  {
    id: "law",
    title: "Prawo & Sukcesja 3.0",
    subtitle: "Zaplanuj i całkowicie zabezpiecz gospodarstwo",
    icon: Scale,
    color: "bg-purple-500",
    badge: null,
    services: [
      { name: "Prawnik & Mediator", description: "Mediacje przedsądowe, porady prawne online", badge: null, hot: false },
      { name: "Krypta Cyfrowa", description: "Transfer dosiępu, historia.pdf, załączniki", badge: "NOWY", hot: true },
      { name: "Symulator Majątku", description: "Algorytm podziału między małby sukcesorów", badge: null, hot: false },
    ]
  },
  {
    id: "robotics",
    title: "Robotyka & Precyzja",
    subtitle: "Technologie nowej ery rolnictwa",
    icon: Cpu,
    color: "bg-orange-500",
    badge: null,
    services: [
      { name: "Predictive Maintenance", description: "Telemetria maszyn · Powiadomienie · Joskin Deere API", badge: null, hot: false },
      { name: "Ortofotomapy Floty & Drony", description: "Mapy HD · Skany wielospektralne · Udostępnienie rolnikom", badge: null, hot: false },
      { name: "Automatyzacja Logi ESG", description: "Pasive logging · Certyfikacja papierów i papierów", badge: null, hot: false },
    ]
  },
  {
    id: "exchange",
    title: "Giełda & Barter 4.0",
    subtitle: "Handel zbożem i wymiana bezgotówkowa",
    icon: RefreshCw,
    color: "bg-cyan-500",
    badge: null,
    services: [
      { name: "Młody za Nawozy", description: "Płatność natychmiastowa na MATIF · Bank BGŻ BNP Paribas", badge: "GPayer", hot: true },
      { name: "Giełda Direct-to-Consumer", description: "Sprzedaż bezpośrednia · Z pominięciem pośredników", badge: null, hot: false },
      { name: "Finanse & Kredyt Barterowy", description: "PKO · BNP Paribas · Leasing plus tax sec", badge: null, hot: false },
    ]
  },
]

const esgSection = {
  title: "ESG & Carbon Farming",
  subtitle: "Mierzenie emisji w jednym miejscu",
  services: [
    { name: "Kalkulator Emisji IoT", icon: Calculator, description: "Automatyzacja · Sertach c.." },
    { name: "Certyfikaty ORCF", icon: Award, description: "Zbadanie CO2 · Spekter de offset" },
    { name: "Popiony & Sekwestracja", icon: Leaf, description: "Najpierw tu musi CO2 być" },
    { name: "Raportowanie ESG", icon: FileText, description: "GRI i rozszerzanie · Auto raporty" },
  ]
}

export default function ServicesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Centrum Usług</h1>
            <p className="text-muted-foreground">Kompleksowe wsparcie dla Twojego gospodarstwa</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Avatar className="h-6 w-6">
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" />
                <AvatarFallback>PZ</AvatarFallback>
              </Avatar>
              <span>Doradca Piotr Zawadzki dostępny</span>
            </div>
            <Button variant="outline" size="sm">Zadzwoń</Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Szukaj usług, produktów, doradców..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Service Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {serviceCategories.map((category) => (
            <Card key={category.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${category.color}`}>
                    <category.icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-base">{category.title}</CardTitle>
                      {category.badge && (
                        <Badge className={`${category.badgeColor} text-white text-xs`}>
                          {category.badge}
                        </Badge>
                      )}
                    </div>
                    <CardDescription className="text-xs">{category.subtitle}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {category.services.map((service, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors group"
                    >
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <div className="h-2 w-2 rounded-full bg-muted-foreground/30" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium truncate">{service.name}</span>
                            {service.badge && (
                              <Badge variant="outline" className="text-xs text-secondary border-secondary">
                                {service.badge}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{service.description}</p>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* ESG & Carbon Farming Section */}
        <Card className="mb-6 border-2 border-green-200 bg-green-50/50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500">
                  <Leaf className="h-5 w-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg">{esgSection.title}</CardTitle>
                  <CardDescription>{esgSection.subtitle}</CardDescription>
                </div>
              </div>
              <Button className="bg-secondary hover:bg-secondary/90">
                Oblicz swój ślad węglowy
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {esgSection.services.map((service, idx) => (
                <div
                  key={idx}
                  className="flex flex-col items-center text-center p-4 rounded-lg bg-card hover:shadow-md transition-shadow cursor-pointer"
                >
                  <div className="p-3 rounded-full bg-green-100 mb-2">
                    <service.icon className="h-5 w-5 text-green-600" />
                  </div>
                  <span className="text-sm font-medium">{service.name}</span>
                  <span className="text-xs text-muted-foreground">{service.description}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-sm">Szybki kredyt</p>
                <p className="text-xs text-muted-foreground">Decyzja w 15 min</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-secondary/10">
                <Shield className="h-5 w-5 text-secondary" />
              </div>
              <div>
                <p className="font-medium text-sm">Ubezpieczenie</p>
                <p className="text-xs text-muted-foreground">Ochrona upraw</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <Target className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-sm">Dotacje EU</p>
                <p className="text-xs text-muted-foreground">Doradztwo</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Stethoscope className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-sm">Telemedycyna</p>
                <p className="text-xs text-muted-foreground">Konsultacja 24/7</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </MainLayout>
  )
}
