"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { PostCard, type Post } from "@/components/post-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import {
  MapPin,
  Calendar,
  Users,
  Edit,
  Camera,
  Tractor,
  Wheat,
  Send,
  MessageCircle,
  Award,
  Star,
  Percent,
  Clock,
  ChevronRight,
  Heart,
  Image as ImageIcon,
  Plus,
  Gift,
  Zap,
  ShoppingCart,
  Tag
} from "lucide-react"

const profileData = {
  name: "Jan Kowalski",
  farm: "Zielona Dolina Farm",
  location: "Mazowieckie, Poland",
  joined: "Member since 2022",
  bio: "3rd generation farmer specializing in wheat and corn production. Passionate about sustainable farming practices and modern agricultural technology.",
  followers: 1245,
  following: 389,
  posts: 156,
  avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
  farmDetails: {
    size: "250 hectares",
    crops: ["Winter Wheat", "Corn", "Rapeseed"],
    certifications: ["GlobalGAP", "Organic in Progress"],
    equipment: 12,
  },
  loyaltyPoints: 3420,
  loyaltyTier: "Kiełek",
}

const userPosts: Post[] = [
  {
    id: 1,
    author: {
      name: "Jan Kowalski",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
      farm: "Zielona Dolina Farm",
    },
    content: "Spring planting is almost done! 120 hectares of corn planted in the last 3 weeks. The weather has been perfect for field work.",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800&auto=format&fit=crop&q=60",
    likes: 89,
    comments: 12,
    shares: 5,
    timestamp: "2 days ago",
  },
  {
    id: 2,
    author: {
      name: "Jan Kowalski",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
      farm: "Zielona Dolina Farm",
    },
    content: "New combine harvester arrived today! Excited to try it out during this year's harvest season.",
    likes: 156,
    comments: 34,
    shares: 8,
    timestamp: "1 week ago",
    liked: true,
  },
]

const fieldPhotos = [
  { id: 1, src: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&h=300&fit=crop", caption: "Wheat field at sunset", likes: 45 },
  { id: 2, src: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400&h=300&fit=crop", caption: "Spring planting", likes: 32 },
  { id: 3, src: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400&h=300&fit=crop", caption: "Corn field", likes: 28 },
  { id: 4, src: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=400&h=300&fit=crop", caption: "Harvest time", likes: 67 },
  { id: 5, src: "https://images.unsplash.com/photo-1592982537447-6f2a6a0c7c18?w=400&h=300&fit=crop", caption: "Morning dew", likes: 23 },
  { id: 6, src: "https://images.unsplash.com/photo-1595841696677-6489ff3f8cd1?w=400&h=300&fit=crop", caption: "Rapeseed blooming", likes: 89 },
]

const specialOffers = [
  {
    id: 1,
    title: "Polifoska 6 - Promocja Sezonowa",
    discount: "15%",
    originalPrice: "2,400 zł/t",
    newPrice: "2,040 zł/t",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=200&h=150&fit=crop",
    expiresIn: "2 dni",
    forYou: true
  },
  {
    id: 2,
    title: "Saletra Amonowa 34%",
    discount: "10%",
    originalPrice: "1,800 zł/t",
    newPrice: "1,620 zł/t",
    image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=200&h=150&fit=crop",
    expiresIn: "5 dni",
    forYou: true
  },
  {
    id: 3,
    title: "Leasing maszyn BNP Paribas",
    discount: "0% prowizji",
    originalPrice: "",
    newPrice: "Bez wpłaty własnej",
    image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=200&h=150&fit=crop",
    expiresIn: "10 dni",
    forYou: false
  },
]

const machines = [
  { id: 1, name: "John Deere 8R Tractor", status: "Active", hours: 2450, image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=100&h=100&fit=crop" },
  { id: 2, name: "Claas Lexion 770 Combine", status: "In Storage", hours: 890, image: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=100&h=100&fit=crop" },
  { id: 3, name: "Amazone Sprayer", status: "Active", hours: 320, image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=100&h=100&fit=crop" },
  { id: 4, name: "Kuhn Planter", status: "Maintenance", hours: 156, image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=100&h=100&fit=crop" },
]

const chatMessages = [
  { id: 1, sender: "Piotr (KAM)", message: "Dzień dobry Panie Janie! Jak mogę dziś pomóc?", time: "10:30", isUser: false },
  { id: 2, sender: "You", message: "Dzień dobry, chciałbym zapytać o nowy program dopłat do nawozów.", time: "10:32", isUser: true },
  { id: 3, sender: "Piotr (KAM)", message: "Oczywiście! Nowy program pokrywa do 30% kosztów nawozów organicznych. Czy chciałby Pan otrzymać formularz zgłoszeniowy?", time: "10:33", isUser: false },
  { id: 4, sender: "Piotr (KAM)", message: "Dodatkowo, mam dla Pana specjalną ofertę na Polifoską - 15% taniej przy zamówieniu powyżej 5 ton!", time: "10:34", isUser: false },
]

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("about")
  const [newMessage, setNewMessage] = useState("")

  return (
    <MainLayout showLeftSidebar={false} showRightSidebar={false}>
      {/* Cover Photo */}
      <div className="relative h-48 md:h-64 bg-gradient-to-r from-primary to-primary/80 rounded-xl overflow-hidden mb-4">
        <img
          src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&auto=format&fit=crop&q=60"
          alt="Farm cover"
          className="w-full h-full object-cover opacity-60"
        />
        <Button
          variant="secondary"
          size="sm"
          className="absolute bottom-4 right-4"
        >
          <Camera className="h-4 w-4 mr-2" />
          Zmień okładkę
        </Button>
      </div>

      {/* Profile Header */}
      <Card className="p-6 -mt-16 relative z-10 mx-4 md:mx-8">
        <div className="flex flex-col md:flex-row md:items-end gap-4">
          <div className="relative">
            <Avatar className="h-32 w-32 border-4 border-card -mt-20">
              <AvatarImage src={profileData.avatar} alt={profileData.name} />
              <AvatarFallback className="bg-primary text-primary-foreground text-3xl">JK</AvatarFallback>
            </Avatar>
            <Button size="icon" className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-secondary hover:bg-secondary/90">
              <Camera className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold text-foreground">{profileData.name}</h1>
                  <Badge className="bg-secondary text-secondary-foreground">
                    <Award className="h-3 w-3 mr-1" />
                    {profileData.loyaltyTier}
                  </Badge>
                </div>
                <p className="text-muted-foreground">{profileData.farm}</p>
                <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {profileData.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {profileData.joined}
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-secondary" />
                    {profileData.loyaltyPoints} pkt
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline">
                  <Gift className="h-4 w-4 mr-2" />
                  Program lojalnościowy
                </Button>
                <Button className="bg-primary hover:bg-primary/90">
                  <Edit className="h-4 w-4 mr-2" />
                  Edytuj profil
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="flex gap-8 mt-6 pt-6 border-t border-border">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{profileData.posts}</p>
            <p className="text-sm text-muted-foreground">Posty</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{profileData.followers.toLocaleString()}</p>
            <p className="text-sm text-muted-foreground">Obserwujący</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">{profileData.following}</p>
            <p className="text-sm text-muted-foreground">Obserwuje</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-secondary">{profileData.loyaltyPoints}</p>
            <p className="text-sm text-muted-foreground">Punktów</p>
          </div>
        </div>
      </Card>

      {/* Special Offers Banner */}
      <div className="mx-4 md:mx-8 mt-6">
        <Card className="overflow-hidden border-2 border-secondary/30 bg-gradient-to-r from-secondary/5 to-secondary/10">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-secondary/20">
                  <Zap className="h-5 w-5 text-secondary" />
                </div>
                <div>
                  <CardTitle className="text-lg">Specjalne oferty dla Ciebie</CardTitle>
                  <p className="text-sm text-muted-foreground">Spersonalizowane na podstawie Twojego profilu</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-secondary">
                Zobacz wszystkie
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {specialOffers.map((offer) => (
                <div key={offer.id} className="relative bg-card rounded-lg overflow-hidden border border-border hover:shadow-lg transition-all group cursor-pointer">
                  <div className="relative h-24">
                    <img src={offer.image} alt={offer.title} className="w-full h-full object-cover" />
                    <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground">
                      -{offer.discount}
                    </Badge>
                    {offer.forYou && (
                      <Badge className="absolute top-2 right-2 bg-secondary text-secondary-foreground">
                        Dla Ciebie
                      </Badge>
                    )}
                  </div>
                  <div className="p-3">
                    <h4 className="font-semibold text-sm truncate">{offer.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      {offer.originalPrice && (
                        <span className="text-xs text-muted-foreground line-through">{offer.originalPrice}</span>
                      )}
                      <span className="text-sm font-bold text-secondary">{offer.newPrice}</span>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      Kończy się za {offer.expiresIn}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs Content */}
      <div className="mt-6 px-4 md:px-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full justify-start bg-card border-b border-border rounded-none p-0 h-auto mb-4 overflow-x-auto">
            <TabsTrigger
              value="about"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
            >
              O mnie
            </TabsTrigger>
            <TabsTrigger
              value="posts"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
            >
              Posty
            </TabsTrigger>
            <TabsTrigger
              value="photos"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
            >
              Zdjęcia z pola
            </TabsTrigger>
            <TabsTrigger
              value="machines"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
            >
              Maszyny
            </TabsTrigger>
            <TabsTrigger
              value="offers"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
            >
              Moje oferty
            </TabsTrigger>
            <TabsTrigger
              value="kam"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
            >
              Chat z KAM
            </TabsTrigger>
          </TabsList>

          <TabsContent value="about" className="mt-0">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="font-semibold text-foreground mb-4">O mnie</h3>
                <p className="text-muted-foreground">{profileData.bio}</p>
              </Card>

              <Card className="p-6">
                <h3 className="font-semibold text-foreground mb-4">Szczegóły gospodarstwa</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Powierzchnia</span>
                    <span className="font-medium text-foreground">{profileData.farmDetails.size}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Sprzęt</span>
                    <span className="font-medium text-foreground">{profileData.farmDetails.equipment} maszyn</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block mb-2">Główne uprawy</span>
                    <div className="flex flex-wrap gap-2">
                      {profileData.farmDetails.crops.map((crop) => (
                        <Badge key={crop} variant="secondary" className="bg-primary/10 text-primary">
                          <Wheat className="h-3 w-3 mr-1" />
                          {crop}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground block mb-2">Certyfikaty</span>
                    <div className="flex flex-wrap gap-2">
                      {profileData.farmDetails.certifications.map((cert) => (
                        <Badge key={cert} variant="outline">
                          {cert}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>

              {/* Loyalty Card */}
              <Card className="p-6 md:col-span-2 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Program lojalnościowy GAia</p>
                    <p className="text-3xl font-bold mt-1">{profileData.loyaltyPoints} punktów</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className="bg-white/20 text-white">{profileData.loyaltyTier}</Badge>
                      <span className="text-sm opacity-90">+1580 pkt do poziomu Żniwa</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm opacity-90 mb-1">Aktualny rabat</p>
                    <p className="text-4xl font-bold">8%</p>
                    <Button variant="secondary" size="sm" className="mt-2">
                      Szczegóły programu
                    </Button>
                  </div>
                </div>
                <div className="mt-4">
                  <Progress value={68} className="h-2 bg-white/20" />
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="posts" className="mt-0 space-y-4">
            {userPosts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </TabsContent>

          <TabsContent value="photos" className="mt-0">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-foreground">Zdjęcia z pola</h3>
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <Plus className="h-4 w-4 mr-2" />
                  Dodaj zdjęcie
                </Button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {fieldPhotos.map((photo) => (
                  <div key={photo.id} className="relative group cursor-pointer overflow-hidden rounded-lg">
                    <img
                      src={photo.src}
                      alt={photo.caption}
                      className="w-full h-40 object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="absolute bottom-2 left-2 right-2">
                        <p className="text-white text-sm font-medium truncate">{photo.caption}</p>
                        <div className="flex items-center gap-1 text-white/80 text-xs">
                          <Heart className="h-3 w-3" />
                          {photo.likes}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="machines" className="mt-0">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-foreground">Inwentarz maszyn</h3>
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <Tractor className="h-4 w-4 mr-2" />
                  Dodaj maszynę
                </Button>
              </div>

              <div className="grid gap-4">
                {machines.map((machine) => (
                  <div key={machine.id} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <img
                        src={machine.image}
                        alt={machine.name}
                        className="h-14 w-14 rounded-lg object-cover"
                      />
                      <div>
                        <p className="font-medium text-foreground">{machine.name}</p>
                        <p className="text-sm text-muted-foreground">{machine.hours} motogodzin</p>
                      </div>
                    </div>
                    <Badge
                      variant={machine.status === "Active" ? "default" : machine.status === "Maintenance" ? "destructive" : "secondary"}
                    >
                      {machine.status === "Active" ? "Aktywna" : machine.status === "Maintenance" ? "Serwis" : "Magazyn"}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="offers" className="mt-0">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Tag className="h-5 w-5 text-secondary" />
                    Moje aktywne oferty sprzedaży
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border border-border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Pszenica ozima</p>
                          <p className="text-sm text-muted-foreground">50 ton - 850 zł/t</p>
                        </div>
                        <Badge className="bg-green-500 text-white">Aktywna</Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                        <Users className="h-4 w-4" />
                        3 zainteresowanych
                      </div>
                    </div>
                    <div className="p-4 border border-border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Kukurydza</p>
                          <p className="text-sm text-muted-foreground">30 ton - 720 zł/t</p>
                        </div>
                        <Badge className="bg-green-500 text-white">Aktywna</Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                        <Users className="h-4 w-4" />
                        1 zainteresowany
                      </div>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj nową ofertę
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5 text-primary" />
                    Historia zakupów
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border border-border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Polifoska 6</p>
                          <p className="text-sm text-muted-foreground">5 ton - 12,000 zł</p>
                        </div>
                        <Badge variant="outline">+150 pkt</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">15 marca 2026</p>
                    </div>
                    <div className="p-4 border border-border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Saletra Amonowa</p>
                          <p className="text-sm text-muted-foreground">3 ton - 5,400 zł</p>
                        </div>
                        <Badge variant="outline">+90 pkt</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">2 marca 2026</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="kam" className="mt-0">
            <Card className="p-4">
              <div className="flex items-center gap-3 mb-4 pb-4 border-b border-border">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" />
                  <AvatarFallback className="bg-secondary text-secondary-foreground">PZ</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-foreground">Piotr Zawadzki</p>
                  <p className="text-sm text-muted-foreground">Twój dedykowany opiekun KAM</p>
                </div>
                <Badge className="ml-auto bg-green-100 text-green-700">Online</Badge>
              </div>

              <div className="h-80 overflow-y-auto space-y-4 mb-4 p-2">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.isUser ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs md:max-w-md p-3 rounded-2xl ${
                        msg.isUser
                          ? "bg-primary text-primary-foreground rounded-br-md"
                          : "bg-muted text-foreground rounded-bl-md"
                      }`}
                    >
                      <p className="text-sm">{msg.message}</p>
                      <p className={`text-xs mt-1 ${msg.isUser ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                        {msg.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Input
                  placeholder="Napisz wiadomość..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1"
                />
                <Button className="bg-secondary hover:bg-secondary/90">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
