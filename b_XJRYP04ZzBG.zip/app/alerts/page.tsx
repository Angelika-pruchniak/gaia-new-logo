"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertTriangle,
  Bug,
  Cloud,
  Droplets,
  MapPin,
  Plus,
  ThermometerSun,
  Wind,
  Leaf,
  Clock,
  Award,
} from "lucide-react"

const alerts = [
  {
    id: 1,
    type: "pest",
    severity: "high",
    title: "Aphid Infestation Alert",
    description: "High concentration of aphids detected in wheat fields. Immediate treatment recommended.",
    location: "5km northwest - Mazowieckie region",
    reportedBy: "Maria Nowak",
    time: "2 hours ago",
    affectedCrops: ["Wheat", "Barley"],
    icon: Bug,
  },
  {
    id: 2,
    type: "weather",
    severity: "medium",
    title: "Heavy Rain Warning",
    description: "Expected rainfall of 30-50mm in the next 24 hours. Consider postponing field work.",
    location: "Your region - Mazowieckie",
    reportedBy: "Weather Service",
    time: "4 hours ago",
    affectedCrops: ["All crops"],
    icon: Cloud,
  },
  {
    id: 3,
    type: "disease",
    severity: "high",
    title: "Fusarium Detection",
    description: "Fusarium head blight symptoms observed. Monitor your wheat fields closely.",
    location: "8km east - neighboring farms",
    reportedBy: "Agricultural Extension",
    time: "6 hours ago",
    affectedCrops: ["Wheat", "Corn"],
    icon: Leaf,
  },
  {
    id: 4,
    type: "weather",
    severity: "low",
    title: "Frost Risk Advisory",
    description: "Temperatures may drop below 0°C tonight. Protect sensitive crops.",
    location: "Regional forecast",
    reportedBy: "Weather Service",
    time: "8 hours ago",
    affectedCrops: ["Vegetables", "Fruit trees"],
    icon: ThermometerSun,
  },
  {
    id: 5,
    type: "pest",
    severity: "medium",
    title: "Colorado Beetle Sighting",
    description: "Colorado beetles spotted in potato fields. Regular monitoring advised.",
    location: "12km south",
    reportedBy: "Piotr Zielinski",
    time: "1 day ago",
    affectedCrops: ["Potatoes"],
    icon: Bug,
  },
]

const mapMarkers = [
  { id: 1, type: "pest", x: 30, y: 25, label: "Aphids" },
  { id: 2, type: "weather", x: 50, y: 40, label: "Rain" },
  { id: 3, type: "disease", x: 70, y: 35, label: "Fusarium" },
  { id: 4, type: "pest", x: 45, y: 60, label: "Beetles" },
  { id: 5, type: "farm", x: 48, y: 42, label: "Your Farm" },
]

const severityColors = {
  high: "bg-red-100 text-red-700 border-red-200",
  medium: "bg-yellow-100 text-yellow-700 border-yellow-200",
  low: "bg-blue-100 text-blue-700 border-blue-200",
}

const typeColors = {
  pest: "bg-orange-500",
  weather: "bg-blue-500",
  disease: "bg-red-500",
  farm: "bg-primary",
}

export default function AlertsPage() {
  const [filterType, setFilterType] = useState("all")
  const [showReportForm, setShowReportForm] = useState(false)

  const filteredAlerts = alerts.filter(
    (alert) => filterType === "all" || alert.type === filterType
  )

  return (
    <MainLayout showRightSidebar={false}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Neighbor Alerts</h1>
            <p className="text-muted-foreground">Stay informed about local agricultural threats</p>
          </div>
          <Button
            className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
            onClick={() => setShowReportForm(!showReportForm)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Report Alert
          </Button>
        </div>

        {/* Interactive Map */}
        <Card className="p-4">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Alert Map
          </h3>
          <div className="relative bg-muted rounded-lg h-64 md:h-80 overflow-hidden">
            {/* Simplified map background */}
            <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-green-200 opacity-50" />
            
            {/* Map markers */}
            {mapMarkers.map((marker) => (
              <div
                key={marker.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                style={{ left: `${marker.x}%`, top: `${marker.y}%` }}
              >
                <div
                  className={`h-4 w-4 rounded-full ${typeColors[marker.type as keyof typeof typeColors]} ring-4 ring-white shadow-lg`}
                />
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-card rounded shadow-lg text-xs font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                  {marker.label}
                </div>
              </div>
            ))}

            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-card rounded-lg p-3 shadow-lg">
              <p className="text-xs font-medium text-foreground mb-2">Legend</p>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-orange-500" />
                  <span className="text-xs text-muted-foreground">Pest</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-blue-500" />
                  <span className="text-xs text-muted-foreground">Weather</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-red-500" />
                  <span className="text-xs text-muted-foreground">Disease</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-primary" />
                  <span className="text-xs text-muted-foreground">Your Farm</span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Report Form */}
        {showReportForm && (
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4">Report a New Alert</h3>
            <p className="text-sm text-muted-foreground mb-4 flex items-center gap-2">
              <Award className="h-4 w-4 text-secondary" />
              Earn +200 loyalty points for verified reports!
            </p>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Alert Type</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pest">Pest Infestation</SelectItem>
                    <SelectItem value="disease">Crop Disease</SelectItem>
                    <SelectItem value="weather">Weather Event</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Severity</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High - Immediate Action</SelectItem>
                    <SelectItem value="medium">Medium - Monitor Closely</SelectItem>
                    <SelectItem value="low">Low - Advisory</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Title</label>
                <Input placeholder="Brief description of the alert" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Affected Crops</label>
                <Input placeholder="e.g., Wheat, Corn, Potatoes" />
              </div>

              <div className="md:col-span-2 space-y-2">
                <label className="text-sm font-medium text-foreground">Details</label>
                <Textarea placeholder="Provide detailed information about what you observed..." className="min-h-24" />
              </div>

              <div className="md:col-span-2 space-y-2">
                <label className="text-sm font-medium text-foreground">Location</label>
                <Input placeholder="Enter location or use current GPS" />
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <Button className="bg-primary hover:bg-primary/90">
                Submit Alert
              </Button>
              <Button variant="outline" onClick={() => setShowReportForm(false)}>
                Cancel
              </Button>
            </div>
          </Card>
        )}

        {/* Filters */}
        <Card className="p-4">
          <div className="flex flex-wrap gap-2">
            <Button
              variant={filterType === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("all")}
              className={filterType === "all" ? "bg-primary hover:bg-primary/90" : ""}
            >
              All Alerts
            </Button>
            <Button
              variant={filterType === "pest" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("pest")}
              className={filterType === "pest" ? "bg-primary hover:bg-primary/90" : ""}
            >
              <Bug className="h-4 w-4 mr-2" />
              Pests
            </Button>
            <Button
              variant={filterType === "disease" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("disease")}
              className={filterType === "disease" ? "bg-primary hover:bg-primary/90" : ""}
            >
              <Leaf className="h-4 w-4 mr-2" />
              Diseases
            </Button>
            <Button
              variant={filterType === "weather" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("weather")}
              className={filterType === "weather" ? "bg-primary hover:bg-primary/90" : ""}
            >
              <Cloud className="h-4 w-4 mr-2" />
              Weather
            </Button>
          </div>
        </Card>

        {/* Alerts List */}
        <div className="space-y-4">
          {filteredAlerts.map((alert) => (
            <Card key={alert.id} className="p-4">
              <div className="flex gap-4">
                <div className={`h-12 w-12 rounded-lg flex items-center justify-center shrink-0 ${
                  alert.severity === "high" ? "bg-red-100" :
                  alert.severity === "medium" ? "bg-yellow-100" : "bg-blue-100"
                }`}>
                  <alert.icon className={`h-6 w-6 ${
                    alert.severity === "high" ? "text-red-600" :
                    alert.severity === "medium" ? "text-yellow-600" : "text-blue-600"
                  }`} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-semibold text-foreground">{alert.title}</h3>
                    <Badge className={severityColors[alert.severity as keyof typeof severityColors]}>
                      {alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1)}
                    </Badge>
                  </div>

                  <p className="text-sm text-muted-foreground mb-3">{alert.description}</p>

                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {alert.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {alert.time}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3">
                    {alert.affectedCrops.map((crop) => (
                      <Badge key={crop} variant="outline" className="text-xs">
                        {crop}
                      </Badge>
                    ))}
                  </div>

                  <p className="text-xs text-muted-foreground mt-3">
                    Reported by: {alert.reportedBy}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </MainLayout>
  )
}
