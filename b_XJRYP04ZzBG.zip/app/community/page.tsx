"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { CreatePost } from "@/components/create-post"
import { PostCard, type Post } from "@/components/post-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Users,
  Search,
  TrendingUp,
  MessageCircle,
  UserPlus,
  Check,
  X,
} from "lucide-react"

const posts: Post[] = [
  {
    id: 1,
    author: {
      name: "Organic Farming Group",
      avatar: "OF",
      farm: "2,450 members",
    },
    content: "Weekly Discussion: What organic pest control methods have worked best for you this season? Share your experiences below!",
    likes: 156,
    comments: 89,
    shares: 12,
    timestamp: "3 hours ago",
  },
  {
    id: 2,
    author: {
      name: "Grain Traders Network",
      avatar: "GT",
      farm: "5,120 members",
    },
    content: "Market Update: Wheat prices are expected to rise by 5-8% next month due to lower yields in Western Europe. Consider holding your stocks if possible.",
    likes: 234,
    comments: 56,
    shares: 78,
    timestamp: "6 hours ago",
    liked: true,
  },
]

const groups = [
  {
    id: 1,
    name: "Organic Farming Poland",
    members: "2,450",
    avatar: "OF",
    description: "Community for organic farmers sharing sustainable practices",
    joined: true,
  },
  {
    id: 2,
    name: "Grain Traders Network",
    members: "5,120",
    avatar: "GT",
    description: "Buy, sell, and discuss grain market trends",
    joined: true,
  },
  {
    id: 3,
    name: "Dairy Farmers Union",
    members: "1,890",
    avatar: "DF",
    description: "Supporting dairy farmers with resources and networking",
    joined: false,
  },
  {
    id: 4,
    name: "Agricultural Technology",
    members: "3,670",
    avatar: "AT",
    description: "Discussing modern farming technology and innovation",
    joined: false,
  },
  {
    id: 5,
    name: "Local Farmers Market",
    members: "892",
    avatar: "LF",
    description: "Connect with local buyers and sell directly",
    joined: true,
  },
]

const experts = [
  {
    id: 1,
    name: "Dr. Anna Kowalska",
    specialty: "Soil Science Expert",
    followers: "12.4k",
    avatar: "AK",
    verified: true,
  },
  {
    id: 2,
    name: "Prof. Jan Mazur",
    specialty: "Crop Protection Specialist",
    followers: "8.9k",
    avatar: "JM",
    verified: true,
  },
  {
    id: 3,
    name: "Marta Wiśniewska",
    specialty: "Organic Certification Advisor",
    followers: "5.2k",
    avatar: "MW",
    verified: true,
  },
]

const trending = [
  { tag: "SpringPlanting", posts: "1.2k" },
  { tag: "WheatPrices2025", posts: "890" },
  { tag: "OrganicFarming", posts: "756" },
  { tag: "DroughtAlert", posts: "534" },
  { tag: "FarmTech", posts: "412" },
]

const groupInvites = [
  {
    id: 1,
    name: "Vegetable Growers Association",
    invitedBy: "Maria Nowak",
    avatar: "VG",
  },
  {
    id: 2,
    name: "Sustainable Farming Initiative",
    invitedBy: "Piotr Kowalski",
    avatar: "SF",
  },
]

export default function CommunityPage() {
  const [activeTab, setActiveTab] = useState("feed")

  return (
    <MainLayout showRightSidebar={false}>
      <div className="flex gap-6">
        {/* Main Content */}
        <div className="flex-1 min-w-0">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full justify-start bg-card border-b border-border rounded-none p-0 h-auto mb-4">
              <TabsTrigger
                value="feed"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
              >
                Feed
              </TabsTrigger>
              <TabsTrigger
                value="groups"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
              >
                Groups
              </TabsTrigger>
              <TabsTrigger
                value="experts"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
              >
                Experts
              </TabsTrigger>
            </TabsList>

            <TabsContent value="feed" className="space-y-4 mt-0">
              <CreatePost />
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </TabsContent>

            <TabsContent value="groups" className="space-y-4 mt-0">
              {/* Search Groups */}
              <Card className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search groups..."
                    className="pl-10"
                  />
                </div>
              </Card>

              {/* Group Invites */}
              {groupInvites.length > 0 && (
                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-3">Group Invitations</h3>
                  <div className="space-y-3">
                    {groupInvites.map((invite) => (
                      <div key={invite.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-12 w-12">
                            <AvatarFallback className="bg-secondary text-secondary-foreground">
                              {invite.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-foreground">{invite.name}</p>
                            <p className="text-sm text-muted-foreground">Invited by {invite.invitedBy}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" className="bg-primary hover:bg-primary/90">
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}

              {/* Groups List */}
              <div className="grid gap-4">
                {groups.map((group) => (
                  <Card key={group.id} className="p-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                          {group.avatar}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-foreground">{group.name}</h3>
                          <Button
                            size="sm"
                            variant={group.joined ? "outline" : "default"}
                            className={group.joined ? "" : "bg-primary hover:bg-primary/90"}
                          >
                            {group.joined ? "Joined" : "Join"}
                          </Button>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{group.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            {group.members} members
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="experts" className="space-y-4 mt-0">
              <Card className="p-4">
                <h3 className="font-semibold text-foreground mb-4">Featured Agricultural Experts</h3>
                <div className="grid gap-4">
                  {experts.map((expert) => (
                    <div key={expert.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-14 w-14">
                          <AvatarFallback className="bg-primary text-primary-foreground">
                            {expert.avatar}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-foreground">{expert.name}</h4>
                            {expert.verified && (
                              <Badge className="bg-primary text-primary-foreground text-xs">Verified</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{expert.specialty}</p>
                          <p className="text-xs text-muted-foreground mt-1">{expert.followers} followers</p>
                        </div>
                      </div>
                      <Button className="bg-primary hover:bg-primary/90">
                        <UserPlus className="h-4 w-4 mr-2" />
                        Follow
                      </Button>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right Sidebar - Community Specific */}
        <aside className="hidden xl:block w-72 shrink-0">
          <div className="sticky top-18 space-y-4">
            {/* Trending Topics */}
            <Card className="p-4">
              <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-secondary" />
                Trending Topics
              </h3>
              <div className="space-y-2">
                {trending.map((topic, index) => (
                  <button
                    key={topic.tag}
                    className="w-full text-left p-2 -mx-2 rounded-lg hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-primary">#{topic.tag}</span>
                      <span className="text-xs text-muted-foreground">{index + 1}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{topic.posts} posts</p>
                  </button>
                ))}
              </div>
            </Card>

            {/* Active Discussions */}
            <Card className="p-4">
              <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-primary" />
                Active Discussions
              </h3>
              <div className="space-y-3">
                <div className="p-2 -mx-2 rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <p className="text-sm font-medium text-foreground">Best fertilizers for spring wheat?</p>
                  <p className="text-xs text-muted-foreground">45 replies • 2h ago</p>
                </div>
                <div className="p-2 -mx-2 rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <p className="text-sm font-medium text-foreground">Weather predictions for April</p>
                  <p className="text-xs text-muted-foreground">32 replies • 4h ago</p>
                </div>
                <div className="p-2 -mx-2 rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <p className="text-sm font-medium text-foreground">EU farming subsidies update</p>
                  <p className="text-xs text-muted-foreground">28 replies • 6h ago</p>
                </div>
              </div>
            </Card>
          </div>
        </aside>
      </div>
    </MainLayout>
  )
}
