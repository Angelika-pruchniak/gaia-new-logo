"use client"

import { MainLayout } from "@/components/main-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Award,
  Gift,
  Star,
  TrendingUp,
  ShoppingCart,
  Users,
  AlertTriangle,
  Calendar,
  Trophy,
  Crown,
  Leaf,
  Sprout,
  Wheat,
  ChevronRight,
} from "lucide-react"

const tiers = [
  { name: "Seed", icon: Sprout, minPoints: 0, color: "bg-green-100 text-green-700", current: false },
  { name: "Sprout", icon: Leaf, minPoints: 500, color: "bg-green-200 text-green-800", current: false },
  { name: "Harvest", icon: Wheat, minPoints: 2000, color: "bg-secondary/20 text-secondary", current: true },
  { name: "Gold", icon: Crown, minPoints: 5000, color: "bg-yellow-100 text-yellow-700", current: false },
]

const earnActivities = [
  { activity: "Post content", points: 10, icon: Users },
  { activity: "Comment on posts", points: 5, icon: Users },
  { activity: "Report neighbor alert", points: 200, icon: AlertTriangle },
  { activity: "Complete purchase", points: 50, icon: ShoppingCart },
  { activity: "Attend event", points: 100, icon: Calendar },
  { activity: "Refer a farmer", points: 500, icon: Users },
]

const redeemOptions = [
  { name: "5% Discount on Seeds", points: 500, category: "Discount" },
  { name: "Free Delivery", points: 300, category: "Shipping" },
  { name: "10% Off Fertilizers", points: 750, category: "Discount" },
  { name: "Premium Support", points: 1000, category: "Service" },
  { name: "Equipment Rental Discount", points: 1500, category: "Discount" },
]

const bonusCombos = [
  {
    name: "Early Bird",
    description: "Complete 3 purchases before 8 AM",
    bonus: "+50 points",
    progress: 2,
    total: 3,
  },
  {
    name: "Community Champion",
    description: "Post 5 times this week",
    bonus: "+100 points",
    progress: 3,
    total: 5,
  },
  {
    name: "Alert Guardian",
    description: "Report 3 verified alerts",
    bonus: "+300 points",
    progress: 1,
    total: 3,
  },
]

const activityLog = [
  { date: "Today", activity: "Posted farm update", points: "+10" },
  { date: "Today", activity: "Commented on discussion", points: "+5" },
  { date: "Yesterday", activity: "Completed marketplace purchase", points: "+50" },
  { date: "Yesterday", activity: "Reported pest alert", points: "+200" },
  { date: "Apr 10", activity: "Attended workshop", points: "+100" },
]

const leaderboard = [
  { rank: 1, name: "Maria Nowak", farm: "Sunny Fields", points: 8450 },
  { rank: 2, name: "Piotr Zielinski", farm: "Green Valley", points: 7820 },
  { rank: 3, name: "Anna Kowalska", farm: "Golden Harvest", points: 6590 },
  { rank: 4, name: "Jan Kowalski", farm: "Zielona Dolina", points: 3245, isUser: true },
  { rank: 5, name: "Tomasz Majewski", farm: "East Meadows", points: 2890 },
]

export default function RewardsPage() {
  const currentPoints = 3245
  const currentTier = "Harvest"
  const nextTierPoints = 5000
  const progressToNext = ((currentPoints - 2000) / (nextTierPoints - 2000)) * 100

  return (
    <MainLayout showRightSidebar={false}>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Loyalty Rewards</h1>
          <p className="text-muted-foreground">Earn points and unlock exclusive benefits</p>
        </div>

        {/* Points Overview */}
        <Card className="p-6 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <p className="text-primary-foreground/80 mb-1">Your Points Balance</p>
              <div className="flex items-center gap-3">
                <Award className="h-10 w-10" />
                <span className="text-4xl font-bold">{currentPoints.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Badge className="bg-secondary text-secondary-foreground">
                  <Wheat className="h-3 w-3 mr-1" />
                  {currentTier} Tier
                </Badge>
              </div>
            </div>

            <div className="flex-1 max-w-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-primary-foreground/80">Progress to Gold</span>
                <span className="text-sm font-medium">{currentPoints} / {nextTierPoints}</span>
              </div>
              <Progress value={progressToNext} className="h-3 bg-primary-foreground/20" />
              <p className="text-xs text-primary-foreground/60 mt-2">
                {nextTierPoints - currentPoints} points to unlock Gold tier benefits
              </p>
            </div>
          </div>
        </Card>

        {/* Tier System */}
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-secondary" />
            Loyalty Tiers
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className={`p-4 rounded-lg border-2 text-center ${
                  tier.current
                    ? "border-secondary bg-secondary/10"
                    : "border-border"
                }`}
              >
                <div className={`h-12 w-12 rounded-full ${tier.color} flex items-center justify-center mx-auto mb-2`}>
                  <tier.icon className="h-6 w-6" />
                </div>
                <p className="font-semibold text-foreground">{tier.name}</p>
                <p className="text-sm text-muted-foreground">{tier.minPoints.toLocaleString()}+ pts</p>
                {tier.current && (
                  <Badge className="mt-2 bg-secondary text-secondary-foreground">Current</Badge>
                )}
              </div>
            ))}
          </div>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Bonus Combos */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              Bonus Combos
            </h3>
            <div className="space-y-4">
              {bonusCombos.map((combo) => (
                <div key={combo.name} className="p-4 border border-border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-foreground">{combo.name}</h4>
                    <Badge variant="outline" className="text-secondary border-secondary">
                      {combo.bonus}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{combo.description}</p>
                  <div className="flex items-center gap-2">
                    <Progress value={(combo.progress / combo.total) * 100} className="flex-1 h-2" />
                    <span className="text-sm text-muted-foreground">
                      {combo.progress}/{combo.total}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Earn Points */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              Ways to Earn
            </h3>
            <div className="space-y-3">
              {earnActivities.map((item) => (
                <div key={item.activity} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center">
                      <item.icon className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span className="text-sm text-foreground">{item.activity}</span>
                  </div>
                  <Badge variant="secondary">+{item.points} pts</Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Redeem Points */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Gift className="h-5 w-5 text-primary" />
              Redeem Rewards
            </h3>
            <div className="space-y-3">
              {redeemOptions.map((option) => (
                <div key={option.name} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted transition-colors">
                  <div>
                    <p className="font-medium text-foreground">{option.name}</p>
                    <p className="text-xs text-muted-foreground">{option.category}</p>
                  </div>
                  <Button
                    size="sm"
                    variant={currentPoints >= option.points ? "default" : "outline"}
                    disabled={currentPoints < option.points}
                    className={currentPoints >= option.points ? "bg-secondary hover:bg-secondary/90 text-secondary-foreground" : ""}
                  >
                    {option.points} pts
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          {/* Activity Log */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4">Recent Activity</h3>
            <div className="space-y-3">
              {activityLog.map((item, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="text-sm text-foreground">{item.activity}</p>
                    <p className="text-xs text-muted-foreground">{item.date}</p>
                  </div>
                  <span className="text-sm font-medium text-green-600">{item.points}</span>
                </div>
              ))}
            </div>
            <Button variant="ghost" className="w-full mt-4 text-primary">
              View Full History
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Card>
        </div>

        {/* Regional Leaderboard */}
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Regional Leaderboard - Mazowieckie
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Rank</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Farmer</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Farm</th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Points</th>
                </tr>
              </thead>
              <tbody>
                {leaderboard.map((entry) => (
                  <tr
                    key={entry.rank}
                    className={`border-b border-border last:border-0 ${
                      entry.isUser ? "bg-primary/5" : ""
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {entry.rank <= 3 ? (
                          <div className={`h-6 w-6 rounded-full flex items-center justify-center ${
                            entry.rank === 1 ? "bg-yellow-100 text-yellow-700" :
                            entry.rank === 2 ? "bg-gray-100 text-gray-700" : "bg-orange-100 text-orange-700"
                          }`}>
                            <Trophy className="h-3 w-3" />
                          </div>
                        ) : (
                          <span className="text-muted-foreground w-6 text-center">{entry.rank}</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`font-medium ${entry.isUser ? "text-primary" : "text-foreground"}`}>
                        {entry.name}
                        {entry.isUser && " (You)"}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-muted-foreground">{entry.farm}</td>
                    <td className="py-3 px-4 text-right font-semibold text-foreground">
                      {entry.points.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </MainLayout>
  )
}
