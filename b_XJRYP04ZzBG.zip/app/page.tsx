import { MainLayout } from "@/components/main-layout"
import { CreatePost } from "@/components/create-post"
import { PostCard, type Post } from "@/components/post-card"

const posts: Post[] = [
  {
    id: 1,
    author: {
      name: "Tomasz Majewski",
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop",
      farm: "Złote Pola",
    },
    content: "Właśnie skończyłem siew 50 hektarów pszenicy ozimej! Warunki glebowe są w tym roku idealne. Mam nadzieję na świetne żniwa. Czy macie jakieś wskazówki dotyczące zwalczania szkodników we wczesnej fazie wzrostu?",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800&auto=format&fit=crop&q=60",
    likes: 124,
    comments: 23,
    shares: 8,
    timestamp: "2 godziny temu",
  },
  {
    id: 2,
    author: {
      name: "Katarzyna Wiśniewska",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop",
      farm: "Eko Farma Wschód Słońca",
    },
    content: "Nasza nowa szklarnia jest wreszcie uruchomiona! Uprawiamy pomidory, papryki i ogórki metodami zrównoważonymi. Certyfikacja ekologiczna w przyszłym miesiącu. Dziękujemy wszystkim, którzy wsparli naszą kampanię crowdfundingową!",
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&auto=format&fit=crop&q=60",
    likes: 256,
    comments: 45,
    shares: 32,
    timestamp: "5 godzin temu",
    liked: true,
  },
  {
    id: 3,
    author: {
      name: "Marek Kowalczyk",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop",
      farm: "Widok na Dolinę Mleczarnia",
    },
    content: "Ważne przypomnienie dla wszystkich rolników mlecznych w naszym regionie: Spotkanie spółdzielni zaplanowane jest na tę sobotę o 10:00. Będziemy omawiać nową strukturę cenową mleka i standardy jakości. Proszę przynieść swoje propozycje!",
    likes: 89,
    comments: 34,
    shares: 15,
    timestamp: "8 godzin temu",
  },
  {
    id: 4,
    author: {
      name: "Anna Nowak",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop",
      farm: "Sady Zielonej Doliny",
    },
    content: "Sezon kwitnienia jabłoni trwa! Nasz sad wygląda pięknie. Spodziewamy się 20% wzrostu plonów w porównaniu z ubiegłym rokiem. Nowy system nawadniania kropelkowego, który zainstalowaliśmy zimą, działa cuda.",
    image: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=800&auto=format&fit=crop&q=60",
    likes: 312,
    comments: 67,
    shares: 45,
    timestamp: "1 dzień temu",
    saved: true,
  },
  {
    id: 5,
    author: {
      name: "Piotr Zieliński",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop",
      farm: "Łąkowa Świeżość",
    },
    content: "Szukam wysokiej jakości nasion rzepaku na przyszły sezon. Czy ktoś ma rekomendacje odmian odpornych na kiłę kapusty? Budżet około 15 000 PLN na 25 hektarów.",
    likes: 45,
    comments: 28,
    shares: 3,
    timestamp: "1 dzień temu",
  },
  {
    id: 6,
    author: {
      name: "Krzysztof Jankowski",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
      farm: "Gospodarstwo Jankowski",
    },
    content: "Alert! W okolicy Mazowsza zauważono pierwsze mszycie zbożowe. Polecam szybką lustrację pól. Udało mi się złapać wczesny sygnał dzięki mapie alertów GAia - świetna funkcja! #MszyceAlertPL",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800&auto=format&fit=crop&q=60",
    likes: 178,
    comments: 42,
    shares: 89,
    timestamp: "3 godziny temu",
  },
]

export default function HomePage() {
  return (
    <MainLayout>
      <div className="space-y-4">
        <CreatePost />
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </MainLayout>
  )
}
