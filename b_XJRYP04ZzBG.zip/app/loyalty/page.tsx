"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Gift,
  Star,
  Trophy,
  Zap,
  ShoppingCart,
  CreditCard,
  Percent,
  Award,
  ChevronRight,
  CheckCircle2,
  TrendingUp,
  Package,
  Leaf,
  Droplets,
  Sparkles,
  Target,
  Crown
} from "lucide-react"

const grupaAzotyProducts = [
  {
    id: 1,
    name: "Polifoska 6",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400&h=300&fit=crop",
    category: "Nawozy wieloskładnikowe",
    points: 150,
    discount: "10%",
    description: "NPK 6-20-30 z siarką",
    inStock: true
  },
  {
    id: 2,
    name: "Saletra Amonowa",
    image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400&h=300&fit=crop",
    category: "Nawozy azotowe",
    points: 120,
    discount: "8%",
    description: "34% N, granulowana",
    inStock: true
  },
  {
    id: 3,
    name: "Mocznik Puławski",
    image: "https://images.unsplash.com/photo-1592982537447-6f2a6a0c7c18?w=400&h=300&fit=crop",
    category: "Nawozy azotowe",
    points: 100,
    discount: "7%",
    description: "46% N, najwyższa jakość",
    inStock: true
  },
  {
    id: 4,
    name: "Polifoska 8",
    image: "https://images.unsplash.com/photo-1500651230702-0e2d8a49d4e7?w=400&h=300&fit=crop",
    category: "Nawozy wieloskładnikowe",
    points: 180,
    discount: "12%",
    description: "NPK 8-24-24 premium",
    inStock: true
  },
  {
    id: 5,
    name: "Saletrzak Puławski",
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400&h=300&fit=crop",
    category: "Nawozy azotowe",
    points: 90,
    discount: "6%",
    description: "27% N z wapniem",
    inStock: true
  },
  {
    id: 6,
    name: "RSM 32",
    image: "https://images.unsplash.com/photo-1595841696677-6489ff3f8cd1?w=400&h=300&fit=crop",
    category: "Nawozy płynne",
    points: 200,
    discount: "15%",
    description: "Roztwór saletrzano-mocznikowy",
    inStock: false
  },
]

const loyaltyTiers = [
  { name: "Ziarno", icon: Leaf, minPoints: 0, maxPoints: 999, color: "bg-green-500", benefits: ["5% rabatu na nawozy", "Darmowa dostawa od 2t"] },
  { name: "Kiełek", icon: Sparkles, minPoints: 1000, maxPoints: 4999, color: "bg-emerald-500", benefits: ["8% rabatu na nawozy", "Priorytetowa dostawa", "Darmowe próbki"] },
  { name: "Żniwa", icon: Trophy, minPoints: 5000, maxPoints: 14999, color: "bg-secondary", benefits: ["12% rabatu na nawozy", "Dedykowany doradca", "Pierwszeństwo w promocjach"] },
  { name: "Złoty", icon: Crown, minPoints: 15000, maxPoints: 999999, color: "bg-yellow-500", benefits: ["15% rabatu na nawozy", "VIP support 24/7", "Ekskluzywne oferty", "Zaproszenia na eventy"] },
]

const earnOptions = [
  { action: "Zakup nawozów Grupa Azoty", points: "1 pkt / 10 zł", icon: Package, multiplier: "2x w sezonie" },
  { action: "Kredyt rolniczy", points: "500 pkt", icon: CreditCard, multiplier: "jednorazowo" },
  { action: "Leasing maszyn", points: "1000 pkt", icon: ShoppingCart, multiplier: "jednorazowo" },
  { action: "Ubezpieczenie upraw", points: "300 pkt", icon: Target, multiplier: "rocznie" },
  { action: "Polecenie znajomego", points: "200 pkt", icon: Gift, multiplier: "za każdego" },
  { action: "Raportowanie alertów", points: "50 pkt", icon: Zap, multiplier: "za każdy" },
]

const recentActivity = [
  { action: "Zakup Polifoska 6 (5t)", points: "+750", date: "Dzisiaj" },
  { action: "Kredyt obrotowy PKO BP", points: "+500", date: "2 dni temu" },
  { action: "Zgłoszenie alertu - mszyca", points: "+50", date: "5 dni temu" },
  { action: "Polecenie - Jan Kowalski", points: "+200", date: "Tydzień temu" },
]

export default function LoyaltyPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const currentPoints = 3420
  const currentTier = loyaltyTiers[1] // Kiełek
  const nextTier = loyaltyTiers[2] // Żniwa
  const progressToNext = ((currentPoints - currentTier.minPoints) / (nextTier.minPoints - currentTier.minPoints)) * 100

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto">
        {/* Header with Points Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="md:col-span-2 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Twoje punkty lojalnościowe</p>
                  <p className="text-4xl font-bold mt-1">{currentPoints.toLocaleString()} pkt</p>
                  <div className="flex items-center gap-2 mt-3">
                    <currentTier.icon className="h-5 w-5" />
                    <span className="font-medium">Poziom: {currentTier.name}</span>
                    <Badge className="bg-white/20 text-white">+{nextTier.minPoints - currentPoints} do {nextTier.name}</Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="p-4 bg-white/10 rounded-full">
                    <Trophy className="h-12 w-12" />
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-1">
                  <span>{currentTier.name}</span>
                  <span>{nextTier.name}</span>
                </div>
                <Progress value={progressToNext} className="h-2 bg-white/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-secondary/10">
                  <Percent className="h-5 w-5 text-secondary" />
                </div>
                <div>
                  <p className="font-semibold">Aktualny rabat</p>
                  <p className="text-2xl font-bold text-secondary">8%</p>
                </div>
              </div>
              <div className="space-y-2">
                {currentTier.benefits.map((benefit, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="overview">Przegląd</TabsTrigger>
            <TabsTrigger value="products">Produkty Grupa Azoty</TabsTrigger>
            <TabsTrigger value="earn">Jak zdobywać punkty</TabsTrigger>
            <TabsTrigger value="redeem">Wymień punkty</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-secondary" />
                    Ostatnia aktywność
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <p className="font-medium text-sm">{item.action}</p>
                          <p className="text-xs text-muted-foreground">{item.date}</p>
                        </div>
                        <Badge className="bg-green-500 text-white">{item.points}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Tiers Overview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-secondary" />
                    Poziomy programu
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {loyaltyTiers.map((tier, idx) => (
                      <div
                        key={idx}
                        className={`flex items-center gap-3 p-3 rounded-lg ${
                          tier.name === currentTier.name ? "bg-primary/10 border-2 border-primary" : "bg-muted/50"
                        }`}
                      >
                        <div className={`p-2 rounded-full ${tier.color}`}>
                          <tier.icon className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{tier.name}</span>
                            {tier.name === currentTier.name && (
                              <Badge variant="outline" className="text-xs">Aktualny</Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">{tier.minPoints.toLocaleString()} - {tier.maxPoints.toLocaleString()} pkt</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="products">
            <div className="mb-4">
              <h2 className="text-xl font-bold">Produkty Grupa Azoty</h2>
              <p className="text-muted-foreground">Zdobywaj punkty za zakupy i odbieraj ekskluzywne rabaty</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {grupaAzotyProducts.map((product) => (
                <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative h-40">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-2 right-2 bg-secondary text-secondary-foreground">
                      {product.discount} taniej
                    </Badge>
                    {!product.inStock && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <Badge variant="destructive">Niedostępny</Badge>
                      </div>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <Badge variant="outline" className="mb-2 text-xs">{product.category}</Badge>
                    <h3 className="font-semibold">{product.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-secondary fill-secondary" />
                        <span className="font-bold text-secondary">{product.points} pkt</span>
                      </div>
                      <Button size="sm" disabled={!product.inStock}>
                        Kup teraz
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Special Promotion Banner */}
            <Card className="mt-6 bg-gradient-to-r from-secondary to-secondary/80 text-secondary-foreground">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className="bg-white/20 text-white mb-2">Promocja sezonowa</Badge>
                    <h3 className="text-xl font-bold">2x punkty za wszystkie nawozy!</h3>
                    <p className="opacity-90">Tylko do końca kwietnia. Zrób zapasy na sezon.</p>
                  </div>
                  <Button className="bg-white text-secondary hover:bg-white/90">
                    Zobacz ofertę
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="earn">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {earnOptions.map((option, idx) => (
                <Card key={idx} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <option.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{option.action}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className="bg-secondary text-secondary-foreground">{option.points}</Badge>
                          <span className="text-xs text-muted-foreground">{option.multiplier}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Credit & Leasing Bonus */}
            <Card className="mt-6 border-2 border-primary">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-full bg-primary/10">
                    <CreditCard className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Bonus za kredyt lub leasing</CardTitle>
                    <CardDescription>Większy rabat przy finansowaniu</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-muted/50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-secondary">+5%</p>
                    <p className="text-sm text-muted-foreground">dodatkowy rabat</p>
                    <p className="text-xs mt-1">przy kredycie rolniczym</p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-secondary">+7%</p>
                    <p className="text-sm text-muted-foreground">dodatkowy rabat</p>
                    <p className="text-xs mt-1">przy leasingu maszyn</p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-secondary">2x</p>
                    <p className="text-sm text-muted-foreground">punkty lojalnościowe</p>
                    <p className="text-xs mt-1">przy pierwszym zakupie</p>
                  </div>
                </div>
                <Button className="w-full mt-4">
                  Sprawdź oferty finansowania
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="redeem">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className="p-4 rounded-full bg-secondary/10 w-fit mx-auto mb-4">
                    <Percent className="h-8 w-8 text-secondary" />
                  </div>
                  <h3 className="font-semibold mb-1">Rabat na nawozy</h3>
                  <p className="text-sm text-muted-foreground mb-3">Wymień punkty na dodatkowy rabat</p>
                  <Badge className="bg-secondary text-secondary-foreground">500 pkt = 5% rabatu</Badge>
                </CardContent>
              </Card>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                    <Truck className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-1">Darmowa dostawa</h3>
                  <p className="text-sm text-muted-foreground mb-3">Bezpłatny transport nawozów</p>
                  <Badge className="bg-primary text-primary-foreground">300 pkt</Badge>
                </CardContent>
              </Card>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className="p-4 rounded-full bg-green-500/10 w-fit mx-auto mb-4">
                    <Gift className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold mb-1">Gadżety GAia</h3>
                  <p className="text-sm text-muted-foreground mb-3">Odzież, akcesoria, narzędzia</p>
                  <Badge className="bg-green-500 text-white">od 100 pkt</Badge>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
