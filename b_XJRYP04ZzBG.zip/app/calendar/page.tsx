"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Users,
  Tractor,
  Wheat,
  Droplets,
} from "lucide-react"

const events = [
  {
    id: 1,
    title: "Spring Planting Workshop",
    date: "2025-04-20",
    time: "10:00 AM",
    type: "event",
    location: "Community Center, Warsaw",
    attendees: 45,
  },
  {
    id: 2,
    title: "Fertilizer Application - Field A",
    date: "2025-04-18",
    time: "6:00 AM",
    type: "task",
    field: "Field A - 50 hectares",
  },
  {
    id: 3,
    title: "Tractor Maintenance",
    date: "2025-04-19",
    time: "9:00 AM",
    type: "maintenance",
    equipment: "John Deere 8R",
  },
  {
    id: 4,
    title: "Farmers Market Day",
    date: "2025-04-25",
    time: "8:00 AM",
    type: "event",
    location: "Local Market Square",
    attendees: 120,
  },
  {
    id: 5,
    title: "Irrigation Check",
    date: "2025-04-22",
    time: "7:00 AM",
    type: "task",
    field: "All Fields",
  },
  {
    id: 6,
    title: "Agricultural Subsidy Deadline",
    date: "2025-04-30",
    time: "11:59 PM",
    type: "deadline",
  },
]

const seasonProgress = [
  { name: "Planting", progress: 65, color: "bg-green-500" },
  { name: "Fertilizing", progress: 40, color: "bg-blue-500" },
  { name: "Pest Control", progress: 20, color: "bg-orange-500" },
]

const eventTypeColors = {
  event: "bg-primary",
  task: "bg-secondary",
  maintenance: "bg-orange-500",
  deadline: "bg-red-500",
}

const eventTypeIcons = {
  event: Users,
  task: Wheat,
  maintenance: Tractor,
  deadline: Clock,
}

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date(2025, 3)) // April 2025
  const [showAddEvent, setShowAddEvent] = useState(false)

  const daysInMonth = new Date(
    currentMonth.getFullYear(),
    currentMonth.getMonth() + 1,
    0
  ).getDate()

  const firstDayOfMonth = new Date(
    currentMonth.getFullYear(),
    currentMonth.getMonth(),
    1
  ).getDay()

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ]

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  const getEventsForDate = (day: number) => {
    const dateStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return events.filter((e) => e.date === dateStr)
  }

  const upcomingEvents = events
    .filter((e) => new Date(e.date) >= new Date("2025-04-13"))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5)

  return (
    <MainLayout showRightSidebar={false}>
      <div className="flex gap-6">
        {/* Main Calendar */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Farm Calendar</h1>
              <p className="text-muted-foreground">Plan and track your farming activities</p>
            </div>
            <Button
              className="bg-primary hover:bg-primary/90"
              onClick={() => setShowAddEvent(!showAddEvent)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Event
            </Button>
          </div>

          {/* Add Event Form */}
          {showAddEvent && (
            <Card className="p-6 mb-6">
              <h3 className="font-semibold text-foreground mb-4">Add New Event</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Event Title</label>
                  <Input placeholder="e.g., Fertilizer Application" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Event Type</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="task">Farm Task</SelectItem>
                      <SelectItem value="event">Community Event</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="deadline">Deadline</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Date</label>
                  <Input type="date" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Time</label>
                  <Input type="time" />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm font-medium text-foreground">Location / Field</label>
                  <Input placeholder="e.g., Field A or Community Center" />
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button className="bg-primary hover:bg-primary/90">Save Event</Button>
                <Button variant="outline" onClick={() => setShowAddEvent(false)}>Cancel</Button>
              </div>
            </Card>
          )}

          {/* Calendar Grid */}
          <Card className="p-4">
            {/* Month Navigation */}
            <div className="flex items-center justify-between mb-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <h2 className="text-lg font-semibold text-foreground">
                {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>

            {/* Day Headers */}
            <div className="grid grid-cols-7 gap-1 mb-2">
              {dayNames.map((day) => (
                <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Days */}
            <div className="grid grid-cols-7 gap-1">
              {/* Empty cells for days before the first day of the month */}
              {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                <div key={`empty-${i}`} className="aspect-square p-1" />
              ))}

              {/* Days of the month */}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1
                const dayEvents = getEventsForDate(day)
                const isToday = day === 13 && currentMonth.getMonth() === 3 && currentMonth.getFullYear() === 2025

                return (
                  <div
                    key={day}
                    className={`aspect-square p-1 border border-border rounded-lg cursor-pointer hover:bg-muted transition-colors ${
                      isToday ? "bg-primary/10 border-primary" : ""
                    }`}
                  >
                    <div className={`text-sm font-medium mb-1 ${isToday ? "text-primary" : "text-foreground"}`}>
                      {day}
                    </div>
                    <div className="flex flex-wrap gap-0.5">
                      {dayEvents.slice(0, 3).map((event) => (
                        <div
                          key={event.id}
                          className={`h-1.5 w-1.5 rounded-full ${eventTypeColors[event.type as keyof typeof eventTypeColors]}`}
                          title={event.title}
                        />
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-4 mt-4 pt-4 border-t border-border">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-primary" />
                <span className="text-sm text-muted-foreground">Events</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-secondary" />
                <span className="text-sm text-muted-foreground">Tasks</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-orange-500" />
                <span className="text-sm text-muted-foreground">Maintenance</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-red-500" />
                <span className="text-sm text-muted-foreground">Deadlines</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <aside className="hidden xl:block w-80 shrink-0">
          <div className="sticky top-18 space-y-4">
            {/* Upcoming Events */}
            <Card className="p-4">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <CalendarIcon className="h-5 w-5 text-primary" />
                Upcoming Events
              </h3>
              <div className="space-y-3">
                {upcomingEvents.map((event) => {
                  const IconComponent = eventTypeIcons[event.type as keyof typeof eventTypeIcons]
                  return (
                    <div key={event.id} className="flex gap-3 p-2 -mx-2 rounded-lg hover:bg-muted transition-colors cursor-pointer">
                      <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${
                        event.type === "event" ? "bg-primary/10" :
                        event.type === "task" ? "bg-secondary/10" :
                        event.type === "maintenance" ? "bg-orange-100" : "bg-red-100"
                      }`}>
                        <IconComponent className={`h-5 w-5 ${
                          event.type === "event" ? "text-primary" :
                          event.type === "task" ? "text-secondary" :
                          event.type === "maintenance" ? "text-orange-600" : "text-red-600"
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{event.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(event.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })} • {event.time}
                        </p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </Card>

            {/* Seasonal Progress */}
            <Card className="p-4">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Wheat className="h-5 w-5 text-secondary" />
                Seasonal Progress
              </h3>
              <div className="space-y-4">
                {seasonProgress.map((item) => (
                  <div key={item.name}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-foreground">{item.name}</span>
                      <span className="text-sm font-medium text-foreground">{item.progress}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full ${item.color} transition-all duration-300`}
                        style={{ width: `${item.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Weather Outlook */}
            <Card className="p-4">
              <h3 className="font-semibold text-foreground mb-4">7-Day Outlook</h3>
              <div className="space-y-2">
                {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => (
                  <div key={day} className="flex items-center justify-between py-1">
                    <span className="text-sm text-muted-foreground">{day}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-foreground">{18 + i}°C</span>
                      <Droplets className={`h-4 w-4 ${i === 2 || i === 3 ? "text-blue-500" : "text-muted-foreground"}`} />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </aside>
      </div>
    </MainLayout>
  )
}
