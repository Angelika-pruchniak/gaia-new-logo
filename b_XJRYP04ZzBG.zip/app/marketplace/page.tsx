"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Search,
  Filter,
  Grid,
  List,
  ShoppingCart,
  Plus,
  Minus,
  MapPin,
  Star,
  Heart,
  Tag,
  Truck,
  Package,
  Leaf,
  Tractor,
  Droplets,
  Wheat,
  X,
} from "lucide-react"

const categories = [
  { id: "all", name: "All Products", icon: Package },
  { id: "seeds", name: "Seeds", icon: Wheat },
  { id: "fertilizers", name: "Fertilizers", icon: Droplets },
  { id: "pesticides", name: "Pesticides", icon: Leaf },
  { id: "machinery", name: "Machinery", icon: Tractor },
  { id: "produce", name: "Fresh Produce", icon: Leaf },
]

const products = [
  {
    id: 1,
    name: "Premium Winter Wheat Seeds",
    seller: "Azoty Agrochemicals",
    price: 450,
    unit: "per 50kg bag",
    rating: 4.8,
    reviews: 234,
    category: "seeds",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400&auto=format&fit=crop&q=60",
    location: "Warsaw",
    shipping: "Free shipping",
    inStock: true,
    verified: true,
  },
  {
    id: 2,
    name: "NPK 15-15-15 Compound Fertilizer",
    seller: "Grupa Azoty",
    price: 1850,
    unit: "per ton",
    rating: 4.9,
    reviews: 567,
    category: "fertilizers",
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&auto=format&fit=crop&q=60",
    location: "Krakow",
    shipping: "Delivery available",
    inStock: true,
    verified: true,
  },
  {
    id: 3,
    name: "Organic Bio-Pesticide Spray",
    seller: "EcoFarm Solutions",
    price: 280,
    unit: "per 5L",
    rating: 4.6,
    reviews: 89,
    category: "pesticides",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400&auto=format&fit=crop&q=60",
    location: "Poznan",
    shipping: "Free shipping over PLN 500",
    inStock: true,
    verified: true,
  },
  {
    id: 4,
    name: "John Deere 5075E Tractor",
    seller: "AgriMachinery Plus",
    price: 185000,
    unit: "",
    rating: 4.9,
    reviews: 45,
    category: "machinery",
    image: "https://images.unsplash.com/photo-1530267981375-f0de937f5f13?w=400&auto=format&fit=crop&q=60",
    location: "Gdansk",
    shipping: "Pickup only",
    inStock: true,
    verified: true,
  },
  {
    id: 5,
    name: "Fresh Organic Potatoes",
    seller: "Green Valley Farm",
    price: 2.5,
    unit: "per kg",
    rating: 4.7,
    reviews: 156,
    category: "produce",
    image: "https://images.unsplash.com/photo-1518977676601-b53f82ber3b?w=400&auto=format&fit=crop&q=60",
    location: "Lublin",
    shipping: "Local delivery",
    inStock: true,
    verified: false,
  },
  {
    id: 6,
    name: "Corn Seeds - Pioneer Brand",
    seller: "Seed Masters Poland",
    price: 680,
    unit: "per unit (80k seeds)",
    rating: 4.8,
    reviews: 312,
    category: "seeds",
    image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=400&auto=format&fit=crop&q=60",
    location: "Wroclaw",
    shipping: "Free shipping",
    inStock: true,
    verified: true,
  },
  {
    id: 7,
    name: "Urea 46% Nitrogen Fertilizer",
    seller: "Azoty Direct",
    price: 2100,
    unit: "per ton",
    rating: 4.7,
    reviews: 423,
    category: "fertilizers",
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400&auto=format&fit=crop&q=60",
    location: "Szczecin",
    shipping: "Bulk delivery available",
    inStock: true,
    verified: true,
  },
  {
    id: 8,
    name: "Fresh Organic Apples",
    seller: "Sunny Orchards",
    price: 4.5,
    unit: "per kg",
    rating: 4.9,
    reviews: 234,
    category: "produce",
    image: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&auto=format&fit=crop&q=60",
    location: "Radom",
    shipping: "Local pickup",
    inStock: true,
    verified: true,
  },
]

const myListings = [
  {
    id: 101,
    name: "Organic Wheat - 50 tons",
    price: 1300,
    unit: "per ton",
    status: "active",
    views: 156,
    inquiries: 8,
  },
  {
    id: 102,
    name: "Farm Equipment - Plow",
    price: 8500,
    unit: "",
    status: "pending",
    views: 45,
    inquiries: 2,
  },
]

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
  unit: string
}

export default function MarketplacePage() {
  const [activeCategory, setActiveCategory] = useState("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [cart, setCart] = useState<CartItem[]>([])
  const [showCart, setShowCart] = useState(false)
  const [activeTab, setActiveTab] = useState("buy")
  const [favorites, setFavorites] = useState<number[]>([])

  const filteredProducts = products.filter((product) => {
    const matchesCategory = activeCategory === "all" || product.category === activeCategory
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.seller.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const addToCart = (product: typeof products[0]) => {
    const existing = cart.find((item) => item.id === product.id)
    if (existing) {
      setCart(cart.map((item) =>
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      ))
    } else {
      setCart([...cart, {
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
        unit: product.unit,
      }])
    }
    setShowCart(true)
  }

  const updateCartQuantity = (id: number, delta: number) => {
    setCart(cart.map((item) => {
      if (item.id === id) {
        const newQuantity = item.quantity + delta
        return newQuantity > 0 ? { ...item, quantity: newQuantity } : item
      }
      return item
    }).filter((item) => item.quantity > 0))
  }

  const removeFromCart = (id: number) => {
    setCart(cart.filter((item) => item.id !== id))
  }

  const toggleFavorite = (id: number) => {
    setFavorites(favorites.includes(id)
      ? favorites.filter((fid) => fid !== id)
      : [...favorites, id]
    )
  }

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <MainLayout showLeftSidebar={false} showRightSidebar={false}>
      <div className="flex gap-6">
        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground">Marketplace</h1>
            <p className="text-muted-foreground">Buy supplies and sell your produce</p>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="bg-muted">
              <TabsTrigger value="buy">Buy Products</TabsTrigger>
              <TabsTrigger value="sell">Sell Products</TabsTrigger>
              <TabsTrigger value="listings">My Listings</TabsTrigger>
            </TabsList>

            <TabsContent value="buy" className="mt-4">
              {/* Search and Filters */}
              <Card className="p-4 mb-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search products, sellers..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Select defaultValue="relevance">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="relevance">Relevance</SelectItem>
                        <SelectItem value="price-low">Price: Low to High</SelectItem>
                        <SelectItem value="price-high">Price: High to Low</SelectItem>
                        <SelectItem value="rating">Highest Rated</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="icon">
                      <Filter className="h-4 w-4" />
                    </Button>
                    <div className="flex border border-border rounded-lg overflow-hidden">
                      <Button
                        variant={viewMode === "grid" ? "secondary" : "ghost"}
                        size="icon"
                        className="rounded-none"
                        onClick={() => setViewMode("grid")}
                      >
                        <Grid className="h-4 w-4" />
                      </Button>
                      <Button
                        variant={viewMode === "list" ? "secondary" : "ghost"}
                        size="icon"
                        className="rounded-none"
                        onClick={() => setViewMode("list")}
                      >
                        <List className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Categories */}
                <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
                  {categories.map((category) => (
                    <Button
                      key={category.id}
                      variant={activeCategory === category.id ? "default" : "outline"}
                      size="sm"
                      className={`shrink-0 gap-2 ${activeCategory === category.id ? "bg-primary hover:bg-primary/90" : ""}`}
                      onClick={() => setActiveCategory(category.id)}
                    >
                      <category.icon className="h-4 w-4" />
                      {category.name}
                    </Button>
                  ))}
                </div>
              </Card>

              {/* Products Grid */}
              <div className={viewMode === "grid"
                ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
                : "space-y-4"
              }>
                {filteredProducts.map((product) => (
                  <Card key={product.id} className={`overflow-hidden ${viewMode === "list" ? "flex" : ""}`}>
                    {/* Image */}
                    <div className={`relative ${viewMode === "list" ? "w-48 shrink-0" : "aspect-[4/3]"}`}>
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                      {product.verified && (
                        <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">
                          Verified
                        </Badge>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`absolute top-2 right-2 h-8 w-8 bg-card/80 hover:bg-card ${favorites.includes(product.id) ? "text-red-500" : ""}`}
                        onClick={() => toggleFavorite(product.id)}
                      >
                        <Heart className={`h-4 w-4 ${favorites.includes(product.id) ? "fill-current" : ""}`} />
                      </Button>
                    </div>

                    {/* Content */}
                    <div className="p-4 flex-1">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-semibold text-foreground line-clamp-2">{product.name}</h3>
                      </div>

                      <p className="text-sm text-muted-foreground mb-2">{product.seller}</p>

                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{product.rating}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">({product.reviews} reviews)</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <MapPin className="h-4 w-4" />
                        <span>{product.location}</span>
                        <span>•</span>
                        <Truck className="h-4 w-4" />
                        <span className="truncate">{product.shipping}</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-lg font-bold text-primary">PLN {product.price.toLocaleString()}</span>
                          {product.unit && (
                            <span className="text-sm text-muted-foreground ml-1">{product.unit}</span>
                          )}
                        </div>
                        <Button
                          size="sm"
                          className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                          onClick={() => addToCart(product)}
                        >
                          <ShoppingCart className="h-4 w-4 mr-1" />
                          Add
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="sell" className="mt-4">
              <Card className="p-6">
                <h2 className="text-xl font-semibold text-foreground mb-4">List a New Product</h2>
                <p className="text-muted-foreground mb-6">
                  Sell your produce, equipment, or supplies to other farmers in the GAia community.
                </p>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Product Name</label>
                    <Input placeholder="e.g., Organic Winter Wheat" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Category</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.filter(c => c.id !== "all").map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Price (PLN)</label>
                    <Input type="number" placeholder="0.00" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Unit</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select unit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">per kg</SelectItem>
                        <SelectItem value="ton">per ton</SelectItem>
                        <SelectItem value="bag">per bag</SelectItem>
                        <SelectItem value="unit">per unit</SelectItem>
                        <SelectItem value="liter">per liter</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Quantity Available</label>
                    <Input type="number" placeholder="e.g., 50" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Location</label>
                    <Input placeholder="e.g., Warsaw, Poland" />
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-medium text-foreground">Description</label>
                    <textarea
                      className="w-full min-h-24 px-3 py-2 border border-input rounded-lg bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="Describe your product, quality, certifications, etc."
                    />
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-medium text-foreground">Product Images</label>
                    <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                      <Package className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">Drag and drop images here, or click to browse</p>
                      <Button variant="outline" className="mt-4">Upload Images</Button>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <Button className="bg-primary hover:bg-primary/90">
                    <Tag className="h-4 w-4 mr-2" />
                    List Product
                  </Button>
                  <Button variant="outline">Save as Draft</Button>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="listings" className="mt-4">
              <Card className="p-4 mb-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-foreground">Your Active Listings</h2>
                  <Button size="sm" className="bg-primary hover:bg-primary/90">
                    <Plus className="h-4 w-4 mr-1" />
                    New Listing
                  </Button>
                </div>
              </Card>

              <div className="space-y-4">
                {myListings.map((listing) => (
                  <Card key={listing.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-foreground">{listing.name}</h3>
                        <p className="text-lg font-bold text-primary mt-1">
                          PLN {listing.price.toLocaleString()}
                          {listing.unit && <span className="text-sm text-muted-foreground ml-1">{listing.unit}</span>}
                        </p>
                      </div>
                      <Badge variant={listing.status === "active" ? "default" : "secondary"}>
                        {listing.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-6 mt-4 text-sm text-muted-foreground">
                      <span>{listing.views} views</span>
                      <span>{listing.inquiries} inquiries</span>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button variant="outline" size="sm">Edit</Button>
                      <Button variant="outline" size="sm">Promote</Button>
                      <Button variant="outline" size="sm" className="text-destructive">Remove</Button>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Cart Sidebar */}
        {showCart && (
          <aside className="hidden lg:block w-80 shrink-0">
            <div className="sticky top-18">
              <Card className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Cart ({cartCount})
                  </h3>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowCart(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                {cart.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">Your cart is empty</p>
                ) : (
                  <>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {cart.map((item) => (
                        <div key={item.id} className="flex items-center gap-3 p-2 bg-muted rounded-lg">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{item.name}</p>
                            <p className="text-sm text-primary">PLN {item.price.toLocaleString()}</p>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-7 w-7"
                              onClick={() => updateCartQuantity(item.id, -1)}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-7 w-7"
                              onClick={() => updateCartQuantity(item.id, 1)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-muted-foreground hover:text-destructive"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-border mt-4 pt-4">
                      <div className="flex items-center justify-between mb-4">
                        <span className="font-semibold text-foreground">Total:</span>
                        <span className="text-xl font-bold text-primary">PLN {cartTotal.toLocaleString()}</span>
                      </div>

                      <Button className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground mb-2">
                        Request Quote
                      </Button>
                      <Button variant="outline" className="w-full">
                        Apply for Financing
                      </Button>
                    </div>
                  </>
                )}
              </Card>
            </div>
          </aside>
        )}
      </div>
    </MainLayout>
  )
}
