"use client"

import { MainLayout } from "@/components/main-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  CreditCard,
  TrendingUp,
  Building2,
  CheckCircle,
  Clock,
  FileText,
  Calculator,
  ChevronRight,
  Shield,
  Percent,
  Calendar,
  Phone,
  Star,
  Award,
  Users,
  Handshake,
  Lock,
  BadgeCheck,
  Sparkles,
} from "lucide-react"

const partnerBanks = [
  {
    id: 1,
    name: "PKO Bank Polski",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/PKO_Bank_Polski_logo.svg/200px-PKO_Bank_Polski_logo.svg.png",
    logoFallback: "PKO",
    rating: 4.8,
    reviews: 2456,
    specialization: "Kredyty rolnicze",
    trusted: true,
  },
  {
    id: 2,
    name: "Bank BNP Paribas",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/BNP_Paribas_logo.svg/200px-BNP_Paribas_logo.svg.png",
    logoFallback: "BNP",
    rating: 4.7,
    reviews: 1823,
    specialization: "Leasing maszyn",
    trusted: true,
  },
  {
    id: 3,
    name: "Bank Pekao S.A.",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Bank_Pekao_logo.svg/200px-Bank_Pekao_logo.svg.png",
    logoFallback: "PEKAO",
    rating: 4.6,
    reviews: 1567,
    specialization: "Dotacje ARiMR",
    trusted: true,
  },
  {
    id: 4,
    name: "SGB Bank",
    logo: "",
    logoFallback: "SGB",
    rating: 4.9,
    reviews: 987,
    specialization: "Bank spółdzielczy",
    trusted: true,
  },
]

const preApprovedLoan = {
  amount: 150000,
  rate: "5.9%",
  term: "60 miesięcy",
  monthlyPayment: 2890,
  status: "Wstępnie zatwierdzony",
}

const loanOffers = [
  {
    id: 1,
    bank: "PKO Bank Polski",
    logoFallback: "PKO",
    type: "Kredyt Rolniczy",
    amount: 150000,
    rate: "5.9%",
    term: "60 miesięcy",
    monthlyPayment: 2890,
    features: ["Bez opłat za wcześniejszą spłatę", "Karencja: 6 miesięcy", "Decyzja w 24h"],
    recommended: true,
    badge: "Najlepsza oferta",
  },
  {
    id: 2,
    bank: "BNP Paribas Leasing",
    logoFallback: "BNP",
    type: "Leasing maszyn",
    amount: 250000,
    rate: "4.8%",
    term: "48 miesięcy",
    monthlyPayment: 5680,
    features: ["100% finansowania", "Wykup 1%", "Ubezpieczenie w racie"],
    recommended: false,
    badge: "Leasing",
  },
  {
    id: 3,
    bank: "Bank Pekao S.A.",
    logoFallback: "PEKAO",
    type: "Kredyt obrotowy",
    amount: 150000,
    rate: "6.2%",
    term: "60 miesięcy",
    monthlyPayment: 2920,
    features: ["Stałe oprocentowanie", "Gwarancja BGK", "Elastyczne spłaty"],
    recommended: false,
    badge: null,
  },
  {
    id: 4,
    bank: "SGB Bank Spółdzielczy",
    logoFallback: "SGB",
    type: "Kredyt preferencyjny",
    amount: 150000,
    rate: "3.5%",
    term: "72 miesiące",
    monthlyPayment: 2320,
    features: ["Dopłaty ARiMR", "Oprocentowanie preferencyjne", "Lokalna obsługa"],
    recommended: false,
    badge: "Z dopłatą",
  },
]

const creditScore = {
  score: 745,
  maxScore: 850,
  status: "Dobry",
  lastUpdated: "10 kwietnia 2025",
  factors: [
    { name: "Historia płatności", status: "Bardzo dobra", impact: "positive" },
    { name: "Wykorzystanie kredytu", status: "Dobra", impact: "positive" },
    { name: "Staż kredytowy", status: "Średni", impact: "neutral" },
    { name: "Ostatnie zapytania", status: "Dobra", impact: "positive" },
  ],
}

const recentTransactions = [
  { date: "12 Kwi", description: "Zakup nasion - Grupa Azoty", amount: -4500, type: "expense" },
  { date: "10 Kwi", description: "Sprzedaż pszenicy", amount: 28500, type: "income" },
  { date: "8 Kwi", description: "Wynajem sprzętu", amount: -1200, type: "expense" },
  { date: "5 Kwi", description: "Wypłata dopłat ARiMR", amount: 12000, type: "income" },
  { date: "3 Kwi", description: "Nawozy - Grupa Azoty", amount: -8900, type: "expense" },
]

const dedicatedAdvisor = {
  name: "Anna Nowak",
  role: "Specjalista ds. Finansów Rolnych",
  phone: "+48 512 345 678",
  avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop",
  available: true,
}

export default function FinancePage() {
  const scorePercentage = (creditScore.score / creditScore.maxScore) * 100

  return (
    <MainLayout showRightSidebar={false}>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Centrum Finansowania</h1>
          <p className="text-muted-foreground">Twoje finansowanie rolnicze w jednym miejscu - bezpiecznie i przejrzyście</p>
        </div>

        {/* Trust Indicators Banner */}
        <Card className="p-4 bg-gradient-to-r from-primary/5 via-secondary/5 to-primary/5 border-primary/20">
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12">
            <div className="flex items-center gap-2 text-foreground">
              <Shield className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Bezpieczne dane</span>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <BadgeCheck className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium">Licencjonowani partnerzy</span>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <Users className="h-5 w-5 text-secondary" />
              <span className="text-sm font-medium">15 000+ rolników</span>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <Lock className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Szyfrowanie SSL</span>
            </div>
          </div>
        </Card>

        {/* Partner Banks */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Handshake className="h-5 w-5 text-secondary" />
            Zaufani Partnerzy Finansowi
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {partnerBanks.map((bank) => (
              <Card key={bank.id} className="p-4 text-center hover:shadow-md transition-shadow">
                <div className="h-12 w-12 mx-auto rounded-full bg-muted flex items-center justify-center mb-3">
                  <span className="font-bold text-primary text-sm">{bank.logoFallback}</span>
                </div>
                <h3 className="font-semibold text-sm text-foreground mb-1">{bank.name}</h3>
                <p className="text-xs text-muted-foreground mb-2">{bank.specialization}</p>
                <div className="flex items-center justify-center gap-1">
                  <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                  <span className="text-xs font-medium text-foreground">{bank.rating}</span>
                  <span className="text-xs text-muted-foreground">({bank.reviews})</span>
                </div>
                {bank.trusted && (
                  <Badge className="mt-2 bg-green-100 text-green-700 text-xs">
                    <BadgeCheck className="h-3 w-3 mr-1" />
                    Zweryfikowany
                  </Badge>
                )}
              </Card>
            ))}
          </div>
        </div>

        {/* Pre-approved Loan Banner */}
        <Card className="p-6 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/20 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-secondary/10 rounded-full translate-y-1/2 -translate-x-1/2" />
          <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <Badge className="bg-green-500 text-white mb-2">
                <CheckCircle className="h-3 w-3 mr-1" />
                {preApprovedLoan.status}
              </Badge>
              <h2 className="text-2xl font-bold mb-1">
                {preApprovedLoan.amount.toLocaleString()} PLN dostępne
              </h2>
              <p className="text-primary-foreground/80">
                {preApprovedLoan.rate} RRSO • {preApprovedLoan.term} • {preApprovedLoan.monthlyPayment.toLocaleString()} PLN/mies.
              </p>
              <p className="text-xs text-primary-foreground/60 mt-2">
                Oferta przygotowana specjalnie dla Ciebie na podstawie Twojej historii w GAia
              </p>
            </div>
            <div className="flex gap-2">
              <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                <Sparkles className="h-4 w-4 mr-2" />
                Złóż wniosek
              </Button>
              <Button variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
                Szczegóły
              </Button>
            </div>
          </div>
        </Card>

        {/* Your Dedicated Advisor */}
        <Card className="p-4 border-secondary/30 bg-secondary/5">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex items-center gap-4 flex-1">
              <div className="relative">
                <Avatar className="h-14 w-14 border-2 border-secondary">
                  <AvatarImage src={dedicatedAdvisor.avatar} alt={dedicatedAdvisor.name} />
                  <AvatarFallback className="bg-secondary text-secondary-foreground">AN</AvatarFallback>
                </Avatar>
                <span className="absolute bottom-0 right-0 h-4 w-4 bg-green-500 rounded-full border-2 border-card" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Twój dedykowany doradca</p>
                <h3 className="font-semibold text-foreground">{dedicatedAdvisor.name}</h3>
                <p className="text-xs text-muted-foreground">{dedicatedAdvisor.role}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Phone className="h-4 w-4 mr-2" />
                {dedicatedAdvisor.phone}
              </Button>
              <Button size="sm" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                Umów spotkanie
              </Button>
            </div>
          </div>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Credit Score */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Twój wynik kredytowy
            </h3>
            <div className="text-center mb-6">
              <div className="relative inline-flex items-center justify-center">
                <svg className="h-32 w-32 transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-muted"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    strokeDasharray={`${scorePercentage * 3.52} 352`}
                    className="text-green-500"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-bold text-foreground">{creditScore.score}</span>
                  <span className="text-sm text-muted-foreground">z {creditScore.maxScore}</span>
                </div>
              </div>
              <Badge className="mt-2 bg-green-100 text-green-700">{creditScore.status}</Badge>
              <p className="text-xs text-muted-foreground mt-2">
                Aktualizacja: {creditScore.lastUpdated}
              </p>
            </div>

            <div className="space-y-2">
              {creditScore.factors.map((factor) => (
                <div key={factor.name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <span className="text-sm text-foreground">{factor.name}</span>
                  <Badge
                    variant="outline"
                    className={
                      factor.impact === "positive"
                        ? "text-green-600 border-green-200"
                        : factor.impact === "negative"
                        ? "text-red-600 border-red-200"
                        : "text-yellow-600 border-yellow-200"
                    }
                  >
                    {factor.status}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>

          {/* Loan Offers */}
          <Card className="p-6 lg:col-span-2">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Porównanie ofert finansowania
            </h3>
            <div className="space-y-4">
              {loanOffers.map((offer) => (
                <div
                  key={offer.id}
                  className={`p-4 border rounded-lg ${
                    offer.recommended ? "border-secondary bg-secondary/5" : "border-border"
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="font-bold text-primary text-xs">{offer.logoFallback}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-semibold text-foreground">{offer.bank}</h4>
                          {offer.badge && (
                            <Badge className={offer.recommended ? "bg-secondary text-secondary-foreground" : "bg-primary/10 text-primary"}>
                              {offer.badge}
                            </Badge>
                          )}
                        </div>
                        <span className="text-xl font-bold text-primary">{offer.rate}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{offer.type}</p>
                      <div className="grid grid-cols-3 gap-4 mb-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Kwota</p>
                          <p className="font-medium text-foreground">{offer.amount.toLocaleString()} PLN</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Okres</p>
                          <p className="font-medium text-foreground">{offer.term}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Rata</p>
                          <p className="font-medium text-foreground">{offer.monthlyPayment.toLocaleString()} PLN</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {offer.features.map((feature) => (
                          <Badge key={feature} variant="outline" className="text-xs">
                            <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Button size="sm" className={offer.recommended ? "bg-secondary hover:bg-secondary/90 text-secondary-foreground" : ""}>
                      Wybierz
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Quick Actions & Transactions */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Quick Actions */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4">Szybkie akcje</h3>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="h-auto flex-col py-4">
                <Calculator className="h-6 w-6 mb-2 text-primary" />
                <span>Kalkulator rat</span>
              </Button>
              <Button variant="outline" className="h-auto flex-col py-4">
                <FileText className="h-6 w-6 mb-2 text-primary" />
                <span>Moje wnioski</span>
              </Button>
              <Button variant="outline" className="h-auto flex-col py-4">
                <Percent className="h-6 w-6 mb-2 text-secondary" />
                <span>Dotacje ARiMR</span>
              </Button>
              <Button variant="outline" className="h-auto flex-col py-4">
                <Calendar className="h-6 w-6 mb-2 text-secondary" />
                <span>Harmonogram spłat</span>
              </Button>
            </div>
          </Card>

          {/* Recent Transactions */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Ostatnie transakcje</h3>
              <Button variant="ghost" size="sm" className="text-primary">
                Zobacz wszystkie
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
            <div className="space-y-3">
              {recentTransactions.map((tx, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="text-sm font-medium text-foreground">{tx.description}</p>
                    <p className="text-xs text-muted-foreground">{tx.date}</p>
                  </div>
                  <span className={`font-semibold ${
                    tx.type === "income" ? "text-green-600" : "text-foreground"
                  }`}>
                    {tx.type === "income" ? "+" : ""}{Math.abs(tx.amount).toLocaleString()} PLN
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Financial Tips */}
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            Wskazówki finansowe dla rolników
          </h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-medium text-foreground mb-2">Planowanie sezonowe</h4>
              <p className="text-sm text-muted-foreground">
                Składaj wnioski o kredyt 2-3 miesiące przed sezonem, aby uzyskać lepsze warunki.
              </p>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-medium text-foreground mb-2">Terminy dopłat</h4>
              <p className="text-sm text-muted-foreground">
                Termin składania wniosków o dopłaty ARiMR upływa 31 maja. Nie czekaj do ostatniej chwili.
              </p>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-medium text-foreground mb-2">Budowanie historii</h4>
              <p className="text-sm text-muted-foreground">
                Regularna aktywność w Market GAia może podnieść Twój wynik kredytowy nawet o 50 punktów.
              </p>
            </div>
          </div>
        </Card>

        {/* Guarantee Banner */}
        <Card className="p-6 bg-gradient-to-r from-green-50 to-green-100/50 border-green-200">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center shrink-0">
              <Shield className="h-8 w-8 text-green-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-foreground text-lg mb-1">Gwarancja bezpieczeństwa GAia</h3>
              <p className="text-sm text-muted-foreground">
                Wszystkie Twoje dane są szyfrowane i chronione. Współpracujemy tylko z licencjonowanymi instytucjami finansowymi 
                nadzorowanymi przez KNF. Twoje bezpieczeństwo jest dla nas priorytetem.
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">100%</p>
                <p className="text-xs text-muted-foreground">Bezpieczeństwo</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">KNF</p>
                <p className="text-xs text-muted-foreground">Nadzór</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </MainLayout>
  )
}
