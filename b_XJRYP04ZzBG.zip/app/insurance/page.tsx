"use client"

import { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Shield,
  Umbrella,
  AlertTriangle,
  CheckCircle,
  FileText,
  Phone,
  Wheat,
  Tractor,
  Cloud,
  ChevronRight,
  Clock,
  Upload,
  Star,
  BadgeCheck,
  Users,
  Heart,
  Award,
  Handshake,
  Lock,
  Sparkles,
  Building,
} from "lucide-react"

const partnerInsurers = [
  {
    id: 1,
    name: "PZU",
    logo: "",
    logoFallback: "PZU",
    rating: 4.9,
    reviews: 3456,
    specialization: "Ubezpieczenia upraw",
    trusted: true,
    since: "Partner od 2020",
  },
  {
    id: 2,
    name: "Warta",
    logo: "",
    logoFallback: "WAR",
    rating: 4.7,
    reviews: 2123,
    specialization: "Maszyny rolnicze",
    trusted: true,
    since: "Partner od 2021",
  },
  {
    id: 3,
    name: "Generali Agro",
    logo: "",
    logoFallback: "GEN",
    rating: 4.8,
    reviews: 1867,
    specialization: "Zwierzęta hodowlane",
    trusted: true,
    since: "Partner od 2019",
  },
  {
    id: 4,
    name: "TUW",
    logo: "",
    logoFallback: "TUW",
    rating: 4.6,
    reviews: 1245,
    specialization: "Ubezpieczenia wzajemne",
    trusted: true,
    since: "Partner od 2022",
  },
]

const insuranceProducts = [
  {
    id: 1,
    name: "Ubezpieczenie Upraw Plus",
    insurer: "PZU",
    description: "Kompleksowa ochrona przed gradem, przymrozkami, suszą i szkodnikami",
    coverage: "do 500 000 PLN",
    premium: "od 4 500 PLN/rok",
    features: [
      "Ochrona przed gradem i przymrozkami",
      "Pokrycie szkód od suszy",
      "Rekompensata za szkodniki",
      "Szybka likwidacja szkód",
      "Dedykowany opiekun",
    ],
    icon: Wheat,
    color: "bg-green-100 text-green-700",
    popular: true,
    rating: 4.9,
    claims: "98% zaakceptowanych",
  },
  {
    id: 2,
    name: "Ochrona Maszyn",
    insurer: "Warta",
    description: "Pełne ubezpieczenie ciągników, kombajnów i sprzętu rolniczego",
    coverage: "wartość odtworzeniowa",
    premium: "od 2 800 PLN/rok",
    features: [
      "Ochrona przed kradzieżą",
      "Ubezpieczenie od wypadków",
      "Assistance 24/7",
      "Wymiana na nowy sprzęt",
      "Pokrycie przestojów",
    ],
    icon: Tractor,
    color: "bg-blue-100 text-blue-700",
    popular: false,
    rating: 4.7,
    claims: "96% zaakceptowanych",
  },
  {
    id: 3,
    name: "Tarcza Pogodowa",
    insurer: "Generali Agro",
    description: "Specjalistyczna ochrona przed ekstremalnymi zjawiskami pogodowymi",
    coverage: "do 300 000 PLN",
    premium: "od 1 900 PLN/rok",
    features: [
      "Ochrona przed burzami",
      "Ubezpieczenie od powodzi",
      "Pokrycie szkód od piorunów",
      "Integracja z alertami GAia",
      "Automatyczne zgłoszenie",
    ],
    icon: Cloud,
    color: "bg-purple-100 text-purple-700",
    popular: false,
    rating: 4.8,
    claims: "97% zaakceptowanych",
  },
]

const activePolicies = [
  {
    id: 1,
    name: "Ubezpieczenie Upraw Plus",
    insurer: "PZU",
    policyNumber: "UUP-2025-0892",
    status: "Aktywna",
    coverage: "500 000 PLN",
    validUntil: "31 grudnia 2025",
    premium: "4 500 PLN/rok",
    nextPayment: "15 czerwca 2025",
  },
  {
    id: 2,
    name: "Ochrona Maszyn",
    insurer: "Warta",
    policyNumber: "OM-2025-1234",
    status: "Aktywna",
    coverage: "250 000 PLN",
    validUntil: "31 grudnia 2025",
    premium: "2 800 PLN/rok",
    nextPayment: "15 czerwca 2025",
  },
]

const recentClaims = [
  {
    id: 1,
    type: "Szkody gradowe",
    date: "15 marca 2025",
    amount: "12 500 PLN",
    status: "Zaakceptowana",
    processTime: "3 dni",
  },
  {
    id: 2,
    type: "Naprawa sprzętu",
    date: "28 lutego 2025",
    amount: "3 200 PLN",
    status: "Wypłacona",
    processTime: "5 dni",
  },
]

const alertTriggeredReview = {
  type: "Alert przymrozkowy",
  date: "12 kwietnia 2025",
  message: "Wykryto alert przymrozkowy w Twoim regionie. Sprawdź czy Twoja polisa zapewnia wystarczającą ochronę.",
}

const dedicatedAgent = {
  name: "Tomasz Wiśniewski",
  role: "Agent ds. Ubezpieczeń Rolnych",
  phone: "+48 501 234 567",
  avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop",
  available: true,
  experience: "12 lat doświadczenia",
}

export default function InsurancePage() {
  const [showClaimForm, setShowClaimForm] = useState(false)

  return (
    <MainLayout showRightSidebar={false}>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Centrum Ubezpieczeń</h1>
          <p className="text-muted-foreground">Kompleksowa ochrona Twojego gospodarstwa - zaufaj ekspertom</p>
        </div>

        {/* Trust Indicators Banner */}
        <Card className="p-4 bg-gradient-to-r from-primary/5 via-secondary/5 to-primary/5 border-primary/20">
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12">
            <div className="flex items-center gap-2 text-foreground">
              <Shield className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">100% ochrony</span>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <BadgeCheck className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium">Licencjonowani ubezpieczyciele</span>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <Clock className="h-5 w-5 text-secondary" />
              <span className="text-sm font-medium">Szybka likwidacja szkód</span>
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <Heart className="h-5 w-5 text-red-500" />
              <span className="text-sm font-medium">20 000+ chronionych rolników</span>
            </div>
          </div>
        </Card>

        {/* Partner Insurers */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Handshake className="h-5 w-5 text-secondary" />
            Zaufani Partnerzy Ubezpieczeniowi
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {partnerInsurers.map((insurer) => (
              <Card key={insurer.id} className="p-4 text-center hover:shadow-md transition-shadow">
                <div className="h-12 w-12 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <span className="font-bold text-primary text-sm">{insurer.logoFallback}</span>
                </div>
                <h3 className="font-semibold text-sm text-foreground mb-1">{insurer.name}</h3>
                <p className="text-xs text-muted-foreground mb-1">{insurer.specialization}</p>
                <p className="text-xs text-secondary mb-2">{insurer.since}</p>
                <div className="flex items-center justify-center gap-1">
                  <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                  <span className="text-xs font-medium text-foreground">{insurer.rating}</span>
                  <span className="text-xs text-muted-foreground">({insurer.reviews})</span>
                </div>
                {insurer.trusted && (
                  <Badge className="mt-2 bg-green-100 text-green-700 text-xs">
                    <BadgeCheck className="h-3 w-3 mr-1" />
                    Zweryfikowany
                  </Badge>
                )}
              </Card>
            ))}
          </div>
        </div>

        {/* Alert-triggered Coverage Review */}
        <Card className="p-4 border-yellow-200 bg-yellow-50">
          <div className="flex items-start gap-4">
            <div className="h-10 w-10 rounded-lg bg-yellow-100 flex items-center justify-center shrink-0">
              <AlertTriangle className="h-5 w-5 text-yellow-700" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-yellow-900">Zalecany przegląd ochrony</h3>
              <p className="text-sm text-yellow-800 mt-1">{alertTriggeredReview.message}</p>
              <p className="text-xs text-yellow-700 mt-2">
                {alertTriggeredReview.type} • {alertTriggeredReview.date}
              </p>
            </div>
            <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700 text-white shrink-0">
              Sprawdź ochronę
            </Button>
          </div>
        </Card>

        {/* Dedicated Agent */}
        <Card className="p-4 border-secondary/30 bg-secondary/5">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex items-center gap-4 flex-1">
              <div className="relative">
                <Avatar className="h-14 w-14 border-2 border-secondary">
                  <AvatarImage src={dedicatedAgent.avatar} alt={dedicatedAgent.name} />
                  <AvatarFallback className="bg-secondary text-secondary-foreground">TW</AvatarFallback>
                </Avatar>
                <span className="absolute bottom-0 right-0 h-4 w-4 bg-green-500 rounded-full border-2 border-card" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Twój agent ubezpieczeniowy</p>
                <h3 className="font-semibold text-foreground">{dedicatedAgent.name}</h3>
                <p className="text-xs text-muted-foreground">{dedicatedAgent.role} • {dedicatedAgent.experience}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Phone className="h-4 w-4 mr-2" />
                {dedicatedAgent.phone}
              </Button>
              <Button size="sm" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                Umów konsultację
              </Button>
            </div>
          </div>
        </Card>

        {/* Insurance Products */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Produkty ubezpieczeniowe</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {insuranceProducts.map((product) => (
              <Card key={product.id} className={`p-6 relative ${product.popular ? "border-secondary ring-1 ring-secondary/20" : ""}`}>
                {product.popular && (
                  <Badge className="absolute top-4 right-4 bg-secondary text-secondary-foreground">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Popularne
                  </Badge>
                )}
                <div className={`h-12 w-12 rounded-lg ${product.color} flex items-center justify-center mb-4`}>
                  <product.icon className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold text-foreground">{product.name}</h3>
                </div>
                <p className="text-xs text-secondary font-medium mb-2">{product.insurer}</p>
                <p className="text-sm text-muted-foreground mb-4">{product.description}</p>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Ochrona</span>
                    <span className="font-medium text-foreground">{product.coverage}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Składka</span>
                    <span className="font-medium text-primary">{product.premium}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-foreground">{product.rating}</span>
                    <span className="text-muted-foreground">•</span>
                    <span className="text-green-600 text-xs">{product.claims}</span>
                  </div>
                </div>

                <ul className="space-y-2 mb-4">
                  {product.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button className={`w-full ${product.popular ? "bg-secondary hover:bg-secondary/90 text-secondary-foreground" : "bg-primary hover:bg-primary/90"}`}>
                  Uzyskaj wycenę
                </Button>
              </Card>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Active Policies */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Twoje aktywne polisy
            </h3>
            <div className="space-y-4">
              {activePolicies.map((policy) => (
                <div key={policy.id} className="p-4 border border-border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="font-medium text-foreground">{policy.name}</h4>
                      <p className="text-xs text-secondary">{policy.insurer}</p>
                      <p className="text-xs text-muted-foreground">{policy.policyNumber}</p>
                    </div>
                    <Badge className="bg-green-100 text-green-700">{policy.status}</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm mt-3">
                    <div>
                      <p className="text-muted-foreground">Suma ubezpieczenia</p>
                      <p className="font-medium text-foreground">{policy.coverage}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Ważna do</p>
                      <p className="font-medium text-foreground">{policy.validUntil}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm">Szczegóły</Button>
                    <Button variant="outline" size="sm">Pobierz PDF</Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent Claims */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Historia szkód
              </h3>
              <Button variant="ghost" size="sm" className="text-primary">
                Zobacz wszystkie
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
            <div className="space-y-3 mb-4">
              {recentClaims.map((claim) => (
                <div key={claim.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div>
                    <p className="font-medium text-foreground">{claim.type}</p>
                    <p className="text-xs text-muted-foreground">{claim.date} • Czas obsługi: {claim.processTime}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-foreground">{claim.amount}</p>
                    <Badge
                      variant="outline"
                      className={
                        claim.status === "Zaakceptowana" ? "text-green-600 border-green-200" :
                        claim.status === "Wypłacona" ? "text-blue-600 border-blue-200" :
                        "text-yellow-600 border-yellow-200"
                      }
                    >
                      {claim.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
            <Button
              className="w-full bg-primary hover:bg-primary/90"
              onClick={() => setShowClaimForm(!showClaimForm)}
            >
              <FileText className="h-4 w-4 mr-2" />
              Zgłoś szkodę
            </Button>
          </Card>
        </div>

        {/* Quick Claim Form */}
        {showClaimForm && (
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4">Szybkie zgłoszenie szkody</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Polisa</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Wybierz polisę" />
                  </SelectTrigger>
                  <SelectContent>
                    {activePolicies.map((policy) => (
                      <SelectItem key={policy.id} value={policy.policyNumber}>
                        {policy.name} - {policy.policyNumber}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Rodzaj szkody</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Wybierz rodzaj" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weather">Szkody pogodowe</SelectItem>
                    <SelectItem value="pest">Szkody od szkodników</SelectItem>
                    <SelectItem value="equipment">Uszkodzenie sprzętu</SelectItem>
                    <SelectItem value="theft">Kradzież</SelectItem>
                    <SelectItem value="other">Inne</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Data zdarzenia</label>
                <Input type="date" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Szacunkowa wartość szkody (PLN)</label>
                <Input type="number" placeholder="0.00" />
              </div>
              <div className="md:col-span-2 space-y-2">
                <label className="text-sm font-medium text-foreground">Opis zdarzenia</label>
                <Textarea
                  placeholder="Opisz szczegółowo zdarzenie i powstałe szkody..."
                  className="min-h-24"
                />
              </div>
              <div className="md:col-span-2 space-y-2">
                <label className="text-sm font-medium text-foreground">Dokumentacja</label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Przeciągnij i upuść zdjęcia lub dokumenty, lub kliknij aby wybrać
                  </p>
                  <Button variant="outline" size="sm" className="mt-2">
                    Wybierz pliki
                  </Button>
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <Button className="bg-primary hover:bg-primary/90">
                Wyślij zgłoszenie
              </Button>
              <Button variant="outline" onClick={() => setShowClaimForm(false)}>
                Anuluj
              </Button>
            </div>
          </Card>
        )}

        {/* Guarantee Banner */}
        <Card className="p-6 bg-gradient-to-r from-green-50 to-green-100/50 border-green-200">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center shrink-0">
              <Shield className="h-8 w-8 text-green-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-foreground text-lg mb-1">Gwarancja obsługi GAia</h3>
              <p className="text-sm text-muted-foreground">
                Współpracujemy tylko z ubezpieczycielami nadzorowanymi przez KNF. Gwarantujemy szybką likwidację szkód, 
                dedykowanego opiekuna i pełne wsparcie na każdym etapie. Twoje gospodarstwo jest w dobrych rękach.
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">97%</p>
                <p className="text-xs text-muted-foreground">Akceptacja szkód</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">3 dni</p>
                <p className="text-xs text-muted-foreground">Średni czas</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Contact Support */}
        <Card className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Potrzebujesz pomocy?</h3>
                <p className="text-sm text-muted-foreground">
                  Nasi specjaliści ds. ubezpieczeń rolnych są dostępni 24/7
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">
                <Clock className="h-4 w-4 mr-2" />
                Umów rozmowę
              </Button>
              <Button className="bg-primary hover:bg-primary/90">
                <Phone className="h-4 w-4 mr-2" />
                Zadzwoń teraz
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </MainLayout>
  )
}
