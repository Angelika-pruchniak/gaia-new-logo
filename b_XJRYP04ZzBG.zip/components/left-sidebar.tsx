"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Newspaper,
  MapPin,
  Calendar,
  Gift,
  Bookmark,
  TrendingUp,
  Cloud,
  Tractor,
  ShoppingCart,
  Settings,
  Shield,
  CreditCard,
  Award,
  Star,
  ChevronRight,
  LayoutGrid
} from "lucide-react"

const quickLinks = [
  { name: "Tablica Społeczności", href: "/community", icon: Users },
  { name: "Moje Grupy", href: "/community?tab=groups", icon: LayoutGrid, badge: "2" },
  { name: "Kalendarz Agro", href: "/calendar", icon: Calendar },
  { name: "Mapa Alertów", href: "/alerts", icon: MapPin, badge: "3" },
  { name: "Wiadomości", href: "/messages", icon: Newspaper, badge: "5" },
]

const servicesLinks = [
  { name: "Market GAia", href: "/marketplace", icon: ShoppingCart, desc: "nawozy • maszyny • usługi" },
  { name: "Usługi GAia", href: "/services", icon: Settings, desc: "finanse • prawo • zdrowie" },
]

const moreLinks = [
  { name: "Trendy w Polsce", href: "/trends", icon: TrendingUp },
  { name: "Baza Wiedzy", href: "/knowledge", icon: Bookmark },
  { name: "Barter 4.0", href: "/barter", icon: Award, badge: "NEW" },
  { name: "Ranking Rolników", href: "/ranking", icon: Star },
]

const shortcuts = [
  { name: "Producenci Pszenicy", members: "2,4k", avatar: "PP" },
  { name: "Rolnictwo Ekologiczne", members: "1,8k", avatar: "RE" },
  { name: "Lokalni Dostawcy", members: "856", avatar: "LD" },
]

export function LeftSidebar() {
  const pathname = usePathname()

  return (
    <aside className="hidden lg:block w-64 shrink-0">
      <div className="sticky top-18 space-y-4">
        {/* User Quick Profile */}
        <div className="bg-primary rounded-xl p-4 text-primary-foreground">
          <Link href="/profile" className="flex items-center gap-3">
            <Avatar className="h-12 w-12 border-2 border-secondary">
              <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop" alt="Jan Kowalski" />
              <AvatarFallback className="bg-secondary text-secondary-foreground">JK</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold">Marek Kowalski</p>
              <p className="text-xs opacity-90">Zielona Dolina Farm</p>
            </div>
          </Link>
          <div className="flex gap-4 mt-4 text-center">
            <div>
              <p className="text-lg font-bold">342</p>
              <p className="text-xs opacity-80">ha</p>
            </div>
            <div>
              <p className="text-lg font-bold">128</p>
              <p className="text-xs opacity-80">połączeń</p>
            </div>
            <div>
              <p className="text-lg font-bold">48</p>
              <p className="text-xs opacity-80">pkt</p>
            </div>
          </div>
        </div>

        {/* Community Links */}
        <nav className="bg-card rounded-xl p-2 border border-border">
          <p className="text-xs text-muted-foreground uppercase tracking-wider px-3 py-2 font-medium">Społeczność</p>
          {quickLinks.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href.split("?")[0])
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-foreground hover:bg-muted"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span className="flex-1">{item.name}</span>
                {item.badge && (
                  <Badge variant="secondary" className="bg-secondary text-secondary-foreground h-5 px-1.5 text-xs">
                    {item.badge}
                  </Badge>
                )}
              </Link>
            )
          })}
        </nav>

        {/* Services */}
        <div className="space-y-2">
          {servicesLinks.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="block bg-card rounded-xl p-3 border border-border hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  "h-10 w-10 rounded-lg flex items-center justify-center",
                  item.href === "/marketplace" ? "bg-secondary/20" : "bg-primary/10"
                )}>
                  <item.icon className={cn(
                    "h-5 w-5",
                    item.href === "/marketplace" ? "text-secondary" : "text-primary"
                  )} />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm text-foreground">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </Link>
          ))}
        </div>

        {/* More Links */}
        <nav className="bg-card rounded-xl p-2 border border-border">
          <p className="text-xs text-muted-foreground uppercase tracking-wider px-3 py-2 font-medium">Więcej</p>
          {moreLinks.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-foreground hover:bg-muted transition-colors"
            >
              <item.icon className="h-5 w-5" />
              <span className="flex-1">{item.name}</span>
              {item.badge && (
                <Badge className="bg-green-500 text-white h-5 px-1.5 text-xs">
                  {item.badge}
                </Badge>
              )}
            </Link>
          ))}
        </nav>

        {/* Your Groups */}
        <div className="bg-card rounded-xl p-4 border border-border">
          <h3 className="font-semibold text-sm text-foreground mb-3">Twoje Grupy</h3>
          <div className="space-y-2">
            {shortcuts.map((group) => (
              <Link
                key={group.name}
                href="/community?tab=groups"
                className="flex items-center gap-3 p-2 -mx-2 rounded-lg hover:bg-muted transition-colors"
              >
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                    {group.avatar}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{group.name}</p>
                  <p className="text-xs text-muted-foreground">{group.members} członków</p>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* GAia Platform Badge */}
        <div className="text-center text-xs text-muted-foreground py-2">
          <p>GAia Platforma Rolnika</p>
          <p className="opacity-70">est. 2024 beta</p>
        </div>
      </div>
    </aside>
  )
}
