"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  Send,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export interface Post {
  id: number
  author: {
    name: string
    avatar: string
    farm: string
  }
  content: string
  image?: string
  likes: number
  comments: number
  shares: number
  timestamp: string
  liked?: boolean
  saved?: boolean
}

interface PostCardProps {
  post: Post
}

export function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(post.liked || false)
  const [saved, setSaved] = useState(post.saved || false)
  const [likesCount, setLikesCount] = useState(post.likes)
  const [showComments, setShowComments] = useState(false)
  const [comment, setComment] = useState("")

  const handleLike = () => {
    setLiked(!liked)
    setLikesCount(liked ? likesCount - 1 : likesCount + 1)
  }

  return (
    <Card className="overflow-hidden">
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={post.author.avatar.startsWith("http") ? post.author.avatar : undefined} alt={post.author.name} />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {post.author.avatar.startsWith("http") ? post.author.name.split(" ").map(n => n[0]).join("") : post.author.avatar}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold text-sm text-foreground">{post.author.name}</p>
            <p className="text-xs text-muted-foreground">
              {post.author.farm} • {post.timestamp}
            </p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Zgłoś post</DropdownMenuItem>
            <DropdownMenuItem>Ukryj post</DropdownMenuItem>
            <DropdownMenuItem>Obserwuj {post.author.name}</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="text-sm text-foreground whitespace-pre-line">{post.content}</p>
      </div>

      {/* Post Image */}
      {post.image && (
        <div className="relative aspect-video bg-muted">
          <img
            src={post.image}
            alt="Post image"
            className="w-full h-full object-cover"
          />
        </div>
      )}

      {/* Post Stats */}
      <div className="px-4 py-2 flex items-center justify-between text-sm text-muted-foreground border-b border-border">
        <span>{likesCount} polubień</span>
        <div className="flex gap-4">
          <button
            onClick={() => setShowComments(!showComments)}
            className="hover:underline"
          >
            {post.comments} komentarzy
          </button>
          <span>{post.shares} udostępnień</span>
        </div>
      </div>

      {/* Post Actions */}
      <div className="px-2 py-1 flex items-center justify-between border-b border-border">
        <Button
          variant="ghost"
          size="sm"
          className={`flex-1 gap-2 ${liked ? "text-red-500" : ""}`}
          onClick={handleLike}
        >
          <Heart className={`h-5 w-5 ${liked ? "fill-current" : ""}`} />
          Lubię
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-1 gap-2"
          onClick={() => setShowComments(!showComments)}
        >
          <MessageCircle className="h-5 w-5" />
          Komentarz
        </Button>
        <Button variant="ghost" size="sm" className="flex-1 gap-2">
          <Share2 className="h-5 w-5" />
          Udostępnij
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className={`h-9 w-9 ${saved ? "text-secondary" : ""}`}
          onClick={() => setSaved(!saved)}
        >
          <Bookmark className={`h-5 w-5 ${saved ? "fill-current" : ""}`} />
        </Button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="p-4 space-y-3">
          {/* Sample Comments */}
          <div className="flex gap-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-muted text-muted-foreground text-xs">MN</AvatarFallback>
            </Avatar>
            <div className="flex-1 bg-muted rounded-lg px-3 py-2">
              <p className="text-sm font-medium text-foreground">Maria Nowak</p>
              <p className="text-sm text-foreground">Świetne postępy! Jaką odmianę uprawiasz?</p>
            </div>
          </div>

          {/* Comment Input */}
          <div className="flex gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop" />
              <AvatarFallback className="bg-primary text-primary-foreground text-xs">MK</AvatarFallback>
            </Avatar>
            <div className="flex-1 flex gap-2">
              <Input
                placeholder="Napisz komentarz..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="flex-1"
              />
              <Button size="icon" className="shrink-0" disabled={!comment.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </Card>
  )
}
