"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import {
  Image,
  MapPin,
  Smile,
  Video,
  X,
} from "lucide-react"

export function CreatePost() {
  const [content, setContent] = useState("")
  const [isExpanded, setIsExpanded] = useState(false)

  const handleSubmit = () => {
    if (content.trim()) {
      // Handle post creation
      setContent("")
      setIsExpanded(false)
    }
  }

  return (
    <Card className="p-4">
      <div className="flex gap-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop" alt="Marek Kowalski" />
          <AvatarFallback className="bg-primary text-primary-foreground">MK</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          {isExpanded ? (
            <div className="space-y-3">
              <div className="relative">
                <Textarea
                  placeholder="Co słychać na Twoim polu?"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="min-h-24 resize-none pr-8"
                  autoFocus
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 h-6 w-6"
                  onClick={() => {
                    setIsExpanded(false)
                    setContent("")
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-primary">
                    <Image className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-primary">
                    <Video className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-primary">
                    <MapPin className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-primary">
                    <Smile className="h-5 w-5" />
                  </Button>
                </div>
                <Button
                  onClick={handleSubmit}
                  disabled={!content.trim()}
                  className="bg-primary hover:bg-primary/90"
                >
                  Opublikuj
                </Button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsExpanded(true)}
              className="w-full text-left bg-muted hover:bg-muted/80 rounded-full px-4 py-2.5 text-sm text-muted-foreground transition-colors"
            >
              {"Co słychać na Twoim polu, Marek?"}
            </button>
          )}
        </div>
      </div>

      {!isExpanded && (
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
          <Button variant="ghost" size="sm" className="flex-1 gap-2 text-muted-foreground" onClick={() => setIsExpanded(true)}>
            <Image className="h-5 w-5 text-green-600" />
            Zdjęcie
          </Button>
          <Button variant="ghost" size="sm" className="flex-1 gap-2 text-muted-foreground" onClick={() => setIsExpanded(true)}>
            <Video className="h-5 w-5 text-red-500" />
            Wideo
          </Button>
          <Button variant="ghost" size="sm" className="flex-1 gap-2 text-muted-foreground" onClick={() => setIsExpanded(true)}>
            <MapPin className="h-5 w-5 text-secondary" />
            Lokalizacja
          </Button>
        </div>
      )}
    </Card>
  )
}
