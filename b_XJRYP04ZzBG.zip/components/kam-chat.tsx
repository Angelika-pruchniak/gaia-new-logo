"use client"

import { useState } from "react"
import { MessageCircle, X, Send, Phone, Video, Minimize2, Maximize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface Message {
  id: number
  text: string
  sender: "user" | "kam"
  timestamp: string
}

export function KamChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Dzień dobry! Jestem Twoim dedykowanym opiekunem. W czym mogę pomóc?",
      sender: "kam",
      timestamp: "10:30"
    },
    {
      id: 2,
      text: "Mamy teraz świetną promocję na nawozy Grupa Azoty - do 15% rabatu przy zakupie powyżej 5 ton!",
      sender: "kam",
      timestamp: "10:31"
    }
  ])

  const handleSend = () => {
    if (!message.trim()) return
    
    const newMessage: Message = {
      id: messages.length + 1,
      text: message,
      sender: "user",
      timestamp: new Date().toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit" })
    }
    
    setMessages([...messages, newMessage])
    setMessage("")
    
    // Simulate KAM response
    setTimeout(() => {
      const response: Message = {
        id: messages.length + 2,
        text: "Dziękuję za wiadomość. Sprawdzę to i odezwę się do Pana w ciągu kilku minut.",
        sender: "kam",
        timestamp: new Date().toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit" })
      }
      setMessages(prev => [...prev, response])
    }, 1500)
  }

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="h-14 w-14 rounded-full bg-secondary hover:bg-secondary/90 text-secondary-foreground shadow-lg"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
        <Badge className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground h-5 w-5 p-0 flex items-center justify-center text-xs">
          1
        </Badge>
      </div>
    )
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 bg-card rounded-xl shadow-2xl border border-border overflow-hidden transition-all duration-300 ${isMinimized ? "w-72 h-14" : "w-80 sm:w-96 h-[500px]"}`}>
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="h-9 w-9 border-2 border-secondary">
              <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" />
              <AvatarFallback>KAM</AvatarFallback>
            </Avatar>
            <span className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-primary" />
          </div>
          <div>
            <p className="font-semibold text-sm">Piotr Zawadzki</p>
            <p className="text-xs opacity-90">Twój opiekun KAM</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {!isMinimized && (
            <>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20">
                <Phone className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20">
                <Video className="h-4 w-4" />
              </Button>
            </>
          )}
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20"
            onClick={() => setIsMinimized(!isMinimized)}
          >
            {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[370px] bg-muted/30">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                    msg.sender === "user"
                      ? "bg-primary text-primary-foreground rounded-br-md"
                      : "bg-card border border-border rounded-bl-md"
                  }`}
                >
                  <p className="text-sm">{msg.text}</p>
                  <p className={`text-xs mt-1 ${msg.sender === "user" ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                    {msg.timestamp}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-3 border-t border-border bg-card">
            <div className="flex gap-2">
              <Input
                placeholder="Napisz wiadomość..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                className="flex-1"
              />
              <Button onClick={handleSend} size="icon" className="bg-secondary hover:bg-secondary/90">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
