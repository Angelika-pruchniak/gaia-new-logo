"use client"

import { Header } from "@/components/header"
import { LeftSidebar } from "@/components/left-sidebar"
import { RightSidebar } from "@/components/right-sidebar"
import { KamChat } from "@/components/kam-chat"

interface MainLayoutProps {
  children: React.ReactNode
  showLeftSidebar?: boolean
  showRightSidebar?: boolean
}

export function MainLayout({
  children,
  showLeftSidebar = true,
  showRightSidebar = true,
}: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="mx-auto max-w-7xl px-4 py-4">
        <div className="flex gap-6">
          {showLeftSidebar && <LeftSidebar />}
          <main className="flex-1 min-w-0">{children}</main>
          {showRightSidebar && <RightSidebar />}
        </div>
      </div>
      <KamChat />
    </div>
  )
}
