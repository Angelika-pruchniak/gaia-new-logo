"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import {
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  MapPin,
  Calendar,
  UserPlus,
  Clock,
  ShoppingCart,
  Zap,
  ChevronRight,
  Leaf,
  Eye,
  Hash
} from "lucide-react"

const onlineUsers = [
  { id: 1, name: "Piotr Wiśniewski", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop", status: "online", activity: "przeglądający ofert" },
  { id: 2, name: "Kamila Zając", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop", status: "online", activity: "w grupie dyskusji" },
  { id: 3, name: "Krzysztof Jankowski", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop", status: "online", activity: "czytający wpisy" },
  { id: 4, name: "Janek Rosiak", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop", status: "away", activity: "3 min temu" },
]

const cropPrices = [
  { name: "Pszenica", price: "842", change: "+2.1%", up: true, unit: "zł/t" },
  { name: "Rzepak", price: "1 924", change: "+1.8%", up: true, unit: "zł/t" },
  { name: "Kukurydza", price: "748", change: "-0.5%", up: false, unit: "zł/t" },
  { name: "Mocznik 46%", price: "1 360", change: "+0.3%", up: true, unit: "zł/t" },
]

const trendingTopics = [
  { tag: "#PszenicaOzima", posts: "3 525 postów dziś" },
  { tag: "#PrzygotowanieDoSezonu", posts: "2 841 postów dziś" },
  { tag: "#Agrotechnika", posts: "1 456 postów dziś" },
  { tag: "#MszyceAlertPL", posts: "987 postów dziś" },
  { tag: "#CukierInPlatyzwal", posts: "654 postów dziś" },
]

const upcomingEvents = [
  { id: 1, date: "22", month: "KWI", title: "Webinar: Mocznik vs RSM 2026", time: "10:00 - 11:00 | platformy zoom" },
  { id: 2, date: "28", month: "KWI", title: "Dzień Otwarty GAia - Lublin", time: "Wizyta na miejscu", badge: "LIVE" },
]

export function RightSidebar() {
  const [countdown, setCountdown] = useState({ hours: 3, minutes: 27, seconds: 30 })

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        let { hours, minutes, seconds } = prev
        if (seconds > 0) {
          seconds--
        } else if (minutes > 0) {
          minutes--
          seconds = 59
        } else if (hours > 0) {
          hours--
          minutes = 59
          seconds = 59
        }
        return { hours, minutes, seconds }
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <aside className="hidden xl:block w-80 shrink-0">
      <div className="sticky top-18 space-y-4">
        {/* Online Now */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-foreground flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              Teraz online
            </h3>
            <span className="text-xs text-muted-foreground">Wszyscy</span>
          </div>
          <div className="space-y-3">
            {onlineUsers.map((user) => (
              <div key={user.id} className="flex items-center gap-3">
                <div className="relative">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                      {user.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card ${user.status === "online" ? "bg-green-500" : "bg-yellow-500"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{user.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{user.activity}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">+ 247 rolników online teraz</p>
        </Card>

        {/* Special Offer Countdown */}
        <Card className="overflow-hidden border-2 border-secondary">
          <div className="bg-secondary p-3">
            <div className="flex items-center gap-2 text-secondary-foreground">
              <Zap className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase">Oferta dnia kończy się za:</span>
            </div>
            <div className="flex gap-2 mt-2">
              <div className="bg-white/20 rounded px-2 py-1 text-center">
                <span className="text-xl font-bold text-white">{String(countdown.hours).padStart(2, '0')}</span>
                <p className="text-xs text-white/80">godz</p>
              </div>
              <span className="text-xl font-bold text-white self-start">:</span>
              <div className="bg-white/20 rounded px-2 py-1 text-center">
                <span className="text-xl font-bold text-white">{String(countdown.minutes).padStart(2, '0')}</span>
                <p className="text-xs text-white/80">min</p>
              </div>
              <span className="text-xl font-bold text-white self-start">:</span>
              <div className="bg-white/20 rounded px-2 py-1 text-center">
                <span className="text-xl font-bold text-white">{String(countdown.seconds).padStart(2, '0')}</span>
                <p className="text-xs text-white/80">sek</p>
              </div>
            </div>
          </div>
          <div className="p-3 bg-card">
            <p className="text-sm font-semibold text-foreground">Mocznik 46 NPK</p>
            <p className="text-xs text-muted-foreground mb-2">Cała dostępna ilość do transakcji. Dostawy w całym województwie.</p>
            <Button size="sm" className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground">
              <ShoppingCart className="h-4 w-4 mr-2" />
              Otwórz Market
            </Button>
          </div>
        </Card>

        {/* Crop Prices */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-secondary" />
              Ceny skupu
            </h3>
            <Link href="/marketplace" className="text-xs text-primary hover:underline">
              + Więcej
            </Link>
          </div>
          <div className="space-y-2">
            {cropPrices.map((crop) => (
              <div key={crop.name} className="flex items-center justify-between py-1.5">
                <span className="text-sm text-foreground">{crop.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-foreground">{crop.price}</span>
                  <Badge
                    variant="secondary"
                    className={`text-xs h-5 ${
                      crop.up
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                    }`}
                  >
                    {crop.up ? <TrendingUp className="h-3 w-3 mr-0.5" /> : <TrendingDown className="h-3 w-3 mr-0.5" />}
                    {crop.change}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Soil Analysis Card */}
        <Card className="overflow-hidden border-green-200 bg-green-50/50">
          <div className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Leaf className="h-5 w-5 text-green-600" />
              <h3 className="font-semibold text-sm text-foreground">Twoja analiza gleby czeka</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              Planujesz badania gleby w tym sezonie? Zamówisz u nas w Mochniuk, Wyniki w czasie 2 dni.
            </p>
            <div className="flex gap-2 mb-3">
              <Badge className="bg-green-600 text-white">NKW</Badge>
              <Badge className="bg-primary text-primary-foreground">Plan nawożenia</Badge>
              <Badge variant="outline">ESG</Badge>
            </div>
            <Button size="sm" variant="outline" className="w-full border-green-600 text-green-700 hover:bg-green-100">
              <Eye className="h-4 w-4 mr-2" />
              Przejdź do Usługi
            </Button>
          </div>
        </Card>

        {/* Trending Topics */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-foreground flex items-center gap-2">
              <Hash className="h-4 w-4 text-primary" />
              Trendy dziś
            </h3>
          </div>
          <div className="space-y-2">
            {trendingTopics.map((topic, idx) => (
              <Link
                key={topic.tag}
                href={`/search?q=${encodeURIComponent(topic.tag)}`}
                className="block p-2 -mx-2 rounded-lg hover:bg-muted transition-colors"
              >
                <p className="text-sm font-medium text-primary">{topic.tag}</p>
                <p className="text-xs text-muted-foreground">{topic.posts}</p>
              </Link>
            ))}
          </div>
        </Card>

        {/* Upcoming Events */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-foreground flex items-center gap-2">
              <Calendar className="h-4 w-4 text-secondary" />
              Nadchodzące
            </h3>
            <span className="text-xs text-muted-foreground">Wszystkie</span>
          </div>
          <div className="space-y-3">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-start gap-3">
                <div className="bg-primary/10 rounded-lg p-2 text-center min-w-[44px]">
                  <p className="text-lg font-bold text-primary leading-none">{event.date}</p>
                  <p className="text-xs text-primary/80">{event.month}</p>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-foreground truncate">{event.title}</p>
                    {event.badge && (
                      <Badge className="bg-red-500 text-white text-xs h-4 px-1">{event.badge}</Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{event.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* KAM Call to Action */}
        <Card className="p-4 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10 border-2 border-secondary">
              <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" />
              <AvatarFallback>PZ</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Wołaj na GAihub</p>
              <p className="text-xs text-muted-foreground">Piotr jest dla Ciebie</p>
            </div>
            <Badge className="bg-green-500 text-white">LIVE</Badge>
          </div>
        </Card>
      </div>
    </aside>
  )
}
